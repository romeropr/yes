# Crew

A private, monochrome iOS app for a small team of persistent AI teammates—not just one chatbot with four avatars.

## What’s included

- **Ace, Scout, Milo and Vera**: a chief of staff, researcher, planner and writer with separate instructions, voice characteristics and working memory.
- **Three ways to work**: direct bot chats, an Ace-led flow, and a shared team room with visible handoffs and `@mentions`.
- **Hands-free voice**: Apple speech recognition and spoken replies with listen → think → speak → listen turn-taking.
- **Approvals**: review proposed Gmail drafts/calendar actions before a separate explicit endpoint can execute them.
- **Autonomous routines**: Cloudflare scheduled runs, on-device activity history and Bark iPhone alerts.
- **Google connection**: OAuth on the backend; Gmail/Calendar tokens are never compiled into the IPA.
- **Custom bots**: name a role, write its working brief, and keep a separate direct conversation and memory.
- **Persistent demo mode**: useful sample interactions, saved locally, clearly labelled so they are not mistaken for live AI.

## Run the app

Requires Node 22+.

```bash
npm ci
npm run check
npm run lint
npm run web
```

For a static browser build:

```bash
npm run build:web
```

The native speech modules require a development/native build; they are not expected to work in Expo Go.

## Build the IPA without a Mac

The repository includes **Build unsigned Crew IPA** in `.github/workflows/build-ipa.yml`.

1. Put this source in a GitHub repository.
2. Open **Actions → Build unsigned Crew IPA → Run workflow**.
3. Enter the bundle ID accepted by your provisioning profile, or keep `com.crew.personal` if appropriate.
4. Download `Crew-unsigned-ipa` from the completed run.
5. Extract the artifact, import the IPA into ESign, sign it with your certificate/profile, and install.

The workflow runs real `expo prebuild`, CocoaPods and `xcodebuild` steps on macOS, verifies a 64-bit Mach-O executable, and packages `Payload/Crew.app`. It does not create a fake IPA or sign with anyone else’s identity.

## Connect real AI and automations

See **[docs/SETUP.md](docs/SETUP.md)** for the no-Mac, guided setup. The included second workflow deploys the Cloudflare backend using encrypted GitHub Secrets.

Free-tier stack:

- Groq API for live text responses
- Cloudflare Workers + D1 + Cron Triggers for the private backend and routines
- Google OAuth for Gmail and Calendar
- Apple Speech/AVSpeech for voice
- Bark for remote iPhone alerts

## Important boundaries

- **£0 does not mean unlimited.** Provider quotas and availability can change; the app reports errors rather than inventing completed work.
- **Hands-free listening runs while voice mode is open.** It is not an always-listening background wake-word service.
- **Routines are event-driven cloud jobs**, not a persistent virtual computer. The included cron checks due routines every 15 minutes.
- **External changes need explicit approval.** The default Gmail action creates a draft; it does not send it.
- **Bark sees notification content** when using its public server. Keep alerts non-sensitive or configure a self-hosted Bark server.
- **Only use certificates, profiles and accounts you are authorised to use.**

## Project map

```text
App.tsx                    Native navigation and app shell
src/screens/               Home, crew, chat, voice, activity and settings
src/store/                 Persistent local state and orchestration
src/services/              Live API, demo responses and secure storage
src/components/            Orb identities, messages, composer and navigation
backend/                   Cloudflare Worker, D1 migrations and scheduled jobs
scripts/build-ipa.sh        Repeatable unsigned iOS build/package script
.github/workflows/          No-Mac IPA and backend deployment workflows
docs/SETUP.md               Guided installation and connection checklist
docs/PRODUCT.md             Agreed product brief and implementation status
```
