interface Env {
  CREW_DB: D1Database;
  CREW_ACCESS_TOKEN?: string;
  GROQ_API_KEY?: string;
  AI_MODEL?: string;
  GOOGLE_CLIENT_ID?: string;
  GOOGLE_CLIENT_SECRET?: string;
  BARK_DEVICE_KEY?: string;
  BARK_SERVER_URL?: string;
}

interface BotDefinition {
  id: string;
  name: string;
  role: string;
  prompt: string;
  memory?: string[];
}

interface ChatRequest {
  message?: string;
  team?: boolean;
  primaryBot?: string;
  bots?: BotDefinition[];
  history?: Array<{ senderId: string; text: string }>;
}

interface RoutineRow {
  id: string;
  name: string;
  description?: string;
  bot_id: string;
  schedule?: string;
  interval_minutes: number;
  enabled: number;
  last_run?: number;
  next_run: number;
  run_count: number;
}

interface GoogleTokenRow {
  access_token: string;
  refresh_token?: string;
  expires_at: number;
  email?: string;
  scope?: string;
}

const GOOGLE_SCOPES = [
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.compose',
  'https://www.googleapis.com/auth/calendar.readonly',
  'https://www.googleapis.com/auth/calendar.events',
].join(' ');

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', ...CORS, 'Cache-Control': 'no-store' },
  });
}

function authorised(request: Request, env: Env) {
  if (!env.CREW_ACCESS_TOKEN) return false;
  return request.headers.get('Authorization') === `Bearer ${env.CREW_ACCESS_TOKEN}`;
}

function requireAuth(request: Request, env: Env) {
  if (!env.CREW_ACCESS_TOKEN) return json({ error: 'Set the CREW_ACCESS_TOKEN secret on the backend.' }, 503);
  if (!authorised(request, env)) return json({ error: 'Invalid or missing Crew access token.' }, 401);
  return null;
}

function text(value: unknown, max = 6000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

async function providerError(response: Response, provider: string) {
  const body = await response.text();
  let detail = body.slice(0, 500);
  try {
    const parsed = JSON.parse(body);
    detail = parsed.error?.message || parsed.error || detail;
  } catch { /* retain plain text */ }
  if (response.status === 429) return `${provider} free-tier limit reached. Wait for the quota window to reset, then try again.`;
  return `${provider} request failed (${response.status}): ${detail}`;
}

async function callAI(env: Env, bot: BotDefinition, history: AIMessage[], task: string, maxWords = 240) {
  if (!env.GROQ_API_KEY) throw new Error('Add GROQ_API_KEY to the backend to enable live AI.');
  const system = `${bot.prompt}\n\nYou are ${bot.name}, the ${bot.role} in a private app called Crew. Today is ${new Date().toISOString().slice(0, 10)}. Respond in ${maxWords} words or fewer unless the user explicitly requests a long draft. Be direct, useful and quietly witty, never abrasive. Do not claim to have browsed, read an email, changed a calendar, sent anything or used a tool unless the conversation contains a verified tool result. If current information or sources are unavailable, say so instead of inventing them. External actions always require a separate explicit approval.\n\nSaved working context:\n${(bot.memory || []).slice(0, 12).map((item) => `- ${text(item, 180)}`).join('\n')}`;
  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.GROQ_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: env.AI_MODEL || 'openai/gpt-oss-20b',
      messages: [{ role: 'system', content: system }, ...history.slice(-16), { role: 'user', content: task }],
      temperature: 0.65,
      max_tokens: Math.min(1300, Math.max(350, maxWords * 3)),
    }),
    signal: AbortSignal.timeout(55_000),
  });
  if (!response.ok) throw new Error(await providerError(response, 'Groq'));
  const data = await response.json() as { choices?: Array<{ message?: { content?: string } }> };
  const answer = data.choices?.[0]?.message?.content?.trim();
  if (!answer) throw new Error('The AI provider returned an empty response.');
  return answer;
}

type AIMessage = { role: 'user' | 'assistant'; content: string };

function chooseSpecialist(bots: BotDefinition[], message: string) {
  const mention = message.match(/@(\w+)/)?.[1]?.toLowerCase();
  if (mention) {
    const found = bots.find((bot) => bot.name.toLowerCase() === mention);
    if (found) return found;
  }
  const find = (id: string) => bots.find((bot) => bot.id === id);
  if (/research|latest|news|evidence|compare|investigate|source/i.test(message)) return find('scout') || bots[0];
  if (/plan|schedule|calendar|routine|priority|organise|organize/i.test(message)) return find('milo') || bots[0];
  if (/write|draft|email|rewrite|script|caption|blog/i.test(message)) return find('vera') || bots[0];
  return find('ace') || bots[0];
}

async function runChat(env: Env, body: ChatRequest) {
  const message = text(body.message);
  if (!message) throw new Error('Write a message first.');
  const bots = (body.bots || []).slice(0, 8).map((bot) => ({
    id: text(bot.id, 80), name: text(bot.name, 80), role: text(bot.role, 120), prompt: text(bot.prompt, 5000), memory: (bot.memory || []).slice(0, 12),
  }));
  if (!bots.length) throw new Error('The request did not include a bot roster.');
  const history: AIMessage[] = (body.history || []).slice(-16).map((item) => ({
    role: item.senderId === 'user' ? 'user' : 'assistant',
    content: text(item.text, 5000),
  }));
  const primary = bots.find((bot) => bot.id === body.primaryBot) || bots[0];

  if (!body.team) {
    const answer = await callAI(env, primary, history, message, 300);
    return [{ botId: primary.id, text: answer, kind: 'text' }];
  }

  const specialist = chooseSpecialist(bots, message);
  const ace = bots.find((bot) => bot.id === 'ace') || primary;
  if (specialist.id === ace.id) {
    const answer = await callAI(env, ace, history, message, 300);
    return [{ botId: ace.id, text: answer, kind: 'text' }];
  }

  const specialistAnswer = await callAI(env, specialist, history, message, 230);
  const synthesisTask = `The user asked: "${message}"\n\n${specialist.name} (${specialist.role}) supplied this specialist pass:\n"""\n${specialistAnswer}\n"""\n\nGive the user a concise final recommendation or next step. Add value rather than repeating the specialist. Keep it under 120 words.`;
  const chiefAnswer = await callAI(env, ace, history, synthesisTask, 130);
  return [
    { botId: ace.id, recipientId: specialist.id, kind: 'handoff', text: `${specialist.name}, take the specialist pass. I’ll pull the final answer together.` },
    { botId: specialist.id, text: specialistAnswer, kind: 'text' },
    { botId: ace.id, text: chiefAnswer, kind: 'text' },
  ];
}

function base64Url(value: string) {
  const bytes = new TextEncoder().encode(value);
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function header(value: unknown, max = 300) {
  return text(value, max).replace(/[\r\n]+/g, ' ');
}

async function exchangeGoogleCode(env: Env, code: string, redirectUri: string) {
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: env.GOOGLE_CLIENT_ID || '',
      client_secret: env.GOOGLE_CLIENT_SECRET || '',
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    }),
  });
  if (!response.ok) throw new Error(await providerError(response, 'Google OAuth'));
  return response.json() as Promise<{ access_token: string; refresh_token?: string; expires_in: number; scope?: string }>;
}

async function validGoogleToken(env: Env): Promise<GoogleTokenRow> {
  const row = await env.CREW_DB.prepare('SELECT * FROM google_tokens WHERE id = 1').first<GoogleTokenRow>();
  if (!row) throw new Error('Google is not connected yet.');
  if (row.expires_at > Date.now() + 60_000) return row;
  if (!row.refresh_token) throw new Error('Google needs to be connected again to renew access.');
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: env.GOOGLE_CLIENT_ID || '', client_secret: env.GOOGLE_CLIENT_SECRET || '',
      refresh_token: row.refresh_token, grant_type: 'refresh_token',
    }),
  });
  if (!response.ok) throw new Error(await providerError(response, 'Google token refresh'));
  const data = await response.json() as { access_token: string; expires_in: number; scope?: string };
  const updated = { ...row, access_token: data.access_token, expires_at: Date.now() + data.expires_in * 1000, scope: data.scope || row.scope };
  await env.CREW_DB.prepare('UPDATE google_tokens SET access_token = ?, expires_at = ?, scope = ?, updated_at = ? WHERE id = 1')
    .bind(updated.access_token, updated.expires_at, updated.scope || '', Date.now()).run();
  return updated;
}

async function googleFetch(env: Env, url: string, init: RequestInit = {}) {
  const token = await validGoogleToken(env);
  const response = await fetch(url, { ...init, headers: { Authorization: `Bearer ${token.access_token}`, 'Content-Type': 'application/json', ...(init.headers || {}) } });
  if (!response.ok) throw new Error(await providerError(response, 'Google'));
  return response;
}

async function createGmailDraft(env: Env, payload: any) {
  const to = header(payload?.to, 300);
  const subject = header(payload?.subject, 300);
  const body = text(payload?.body, 20_000);
  if (!to || !subject || !body) throw new Error('A Gmail draft needs a recipient, subject and body.');
  const mime = `To: ${to}\r\nSubject: ${subject}\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n${body}`;
  const response = await googleFetch(env, 'https://gmail.googleapis.com/gmail/v1/users/me/drafts', {
    method: 'POST', body: JSON.stringify({ message: { raw: base64Url(mime) } }),
  });
  const data = await response.json() as { id: string };
  return data.id;
}

async function createCalendarEvent(env: Env, payload: any) {
  const summary = header(payload?.summary || payload?.subject, 300);
  const start = text(payload?.start, 100);
  const end = text(payload?.end, 100);
  if (!summary || !start || !end) throw new Error('A calendar event needs a title, start and end.');
  const response = await googleFetch(env, 'https://www.googleapis.com/calendar/v3/calendars/primary/events', {
    method: 'POST', body: JSON.stringify({ summary, start: { dateTime: start }, end: { dateTime: end }, description: text(payload?.body, 5000) }),
  });
  const data = await response.json() as { id: string };
  return data.id;
}

async function sendBark(env: Env, title: string, body: string, group = 'Crew') {
  if (!env.BARK_DEVICE_KEY) throw new Error('Add BARK_DEVICE_KEY to enable iPhone alerts.');
  const server = (env.BARK_SERVER_URL || 'https://api.day.app').replace(/\/+$/, '');
  const response = await fetch(`${server}/push`, {
    method: 'POST', headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify({ device_key: env.BARK_DEVICE_KEY, title: title.slice(0, 120), body: body.slice(0, 1800), group, level: 'active', url: 'crew://activity' }),
  });
  if (!response.ok) throw new Error(await providerError(response, 'Bark'));
  return true;
}

async function collectGoogleSignals(env: Env) {
  const now = new Date();
  const tomorrow = new Date(now.getTime() + 24 * 60 * 60_000);
  const [calendarResponse, gmailResponse] = await Promise.all([
    googleFetch(env, `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${encodeURIComponent(now.toISOString())}&timeMax=${encodeURIComponent(tomorrow.toISOString())}&singleEvents=true&orderBy=startTime&maxResults=6`),
    googleFetch(env, 'https://gmail.googleapis.com/gmail/v1/users/me/messages?q=is%3Aunread%20newer_than%3A1d&maxResults=4'),
  ]);
  const calendar = await calendarResponse.json() as { items?: Array<{ summary?: string; start?: { dateTime?: string; date?: string } }> };
  const gmail = await gmailResponse.json() as { messages?: Array<{ id: string }> };
  const emailDetails = await Promise.all((gmail.messages || []).slice(0, 4).map(async ({ id }) => {
    const response = await googleFetch(env, `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From`);
    const data = await response.json() as { snippet?: string; payload?: { headers?: Array<{ name: string; value: string }> } };
    const headers = data.payload?.headers || [];
    return { from: headers.find((item) => item.name === 'From')?.value || 'Unknown sender', subject: headers.find((item) => item.name === 'Subject')?.value || '(no subject)', snippet: data.snippet || '' };
  }));
  return {
    events: (calendar.items || []).map((item) => ({ title: item.summary || '(untitled)', start: item.start?.dateTime || item.start?.date || '' })),
    emails: emailDetails,
  };
}

async function runRoutine(env: Env, routine: RoutineRow) {
  const now = Date.now();
  try {
    const signals = await collectGoogleSignals(env);
    const bot: BotDefinition = { id: routine.bot_id || 'ace', name: 'Ace', role: 'Chief of Staff', prompt: 'Create concise, realistic personal briefings. Never invent events or email content.' };
    const task = `Routine: ${routine.name}\nInstructions: ${routine.description || 'Prepare a useful briefing.'}\n\nVerified Google data:\n${JSON.stringify(signals)}\n\nSummarise this into a short phone notification. Put the most important item first. If there is nothing urgent, say so plainly. Do not take any action.`;
    const briefing = await callAI(env, bot, [], task, 190);
    await sendBark(env, routine.name, briefing, 'Crew routines');
    await env.CREW_DB.prepare('INSERT OR REPLACE INTO audit_log (id, kind, detail, created_at) VALUES (?, ?, ?, ?)')
      .bind(crypto.randomUUID(), 'routine', `${routine.name}: ${briefing.slice(0, 400)}`, now).run();
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Routine failed.';
    if (env.BARK_DEVICE_KEY) await sendBark(env, `${routine.name} needs attention`, message, 'Crew routines').catch(() => false);
  }
  await env.CREW_DB.prepare('UPDATE routines SET last_run = ?, next_run = ?, run_count = run_count + 1 WHERE id = ?')
    .bind(now, now + Math.max(15, routine.interval_minutes) * 60_000, routine.id).run();
}

async function audit(env: Env, kind: string, detail: string) {
  await env.CREW_DB.prepare('INSERT OR REPLACE INTO audit_log (id, kind, detail, created_at) VALUES (?, ?, ?, ?)')
    .bind(crypto.randomUUID(), kind, detail.slice(0, 800), Date.now()).run();
}

async function handleRequest(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  const url = new URL(request.url);

  if (url.pathname === '/') return json({ name: 'Crew API', status: 'ready', docs: 'See the included SETUP.md' });

  if (url.pathname === '/auth/google/callback') {
    try {
      const state = text(url.searchParams.get('state'), 200);
      const code = text(url.searchParams.get('code'), 4000);
      const saved = state ? await env.CREW_DB.prepare('SELECT state, created_at FROM oauth_states WHERE state = ?').bind(state).first<{ state: string; created_at: number }>() : null;
      if (!saved || !code || Date.now() - saved.created_at > 10 * 60_000) return new Response('OAuth state expired. Return to Crew and try again.', { status: 400 });
      await env.CREW_DB.prepare('DELETE FROM oauth_states WHERE state = ?').bind(state).run();
      const redirectUri = `${url.origin}/auth/google/callback`;
      const tokens = await exchangeGoogleCode(env, code, redirectUri);
      await env.CREW_DB.prepare(`INSERT INTO google_tokens (id, access_token, refresh_token, expires_at, scope, updated_at) VALUES (1, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET access_token = excluded.access_token, refresh_token = COALESCE(excluded.refresh_token, google_tokens.refresh_token), expires_at = excluded.expires_at, scope = excluded.scope, updated_at = excluded.updated_at`)
        .bind(tokens.access_token, tokens.refresh_token || null, Date.now() + tokens.expires_in * 1000, tokens.scope || GOOGLE_SCOPES, Date.now()).run();
      await audit(env, 'google', 'Google account connected');
      return Response.redirect('crew://google-connected?status=success', 302);
    } catch (error) {
      return new Response(`Google connection failed: ${error instanceof Error ? error.message : 'unknown error'}`, { status: 400 });
    }
  }

  const authError = requireAuth(request, env);
  if (authError) return authError;

  try {
    if (url.pathname === '/v1/health' && request.method === 'GET') {
      const google = await env.CREW_DB.prepare('SELECT id FROM google_tokens WHERE id = 1').first();
      return json({ ok: true, ai: !!env.GROQ_API_KEY, google: !!google, bark: !!env.BARK_DEVICE_KEY, model: env.AI_MODEL || 'openai/gpt-oss-20b' });
    }

    if (url.pathname === '/v1/chat' && request.method === 'POST') {
      const body = await request.json() as ChatRequest;
      const messages = await runChat(env, body);
      ctx.waitUntil(audit(env, 'chat', `${body.team ? 'team' : 'direct'} chat completed`).catch(() => undefined));
      return json({ messages });
    }

    if (url.pathname === '/v1/google/connect' && request.method === 'POST') {
      if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) return json({ error: 'Add both Google OAuth secrets to the backend first.' }, 503);
      const state = `${crypto.randomUUID()}-${crypto.randomUUID()}`;
      await env.CREW_DB.prepare('DELETE FROM oauth_states WHERE created_at < ?').bind(Date.now() - 60 * 60_000).run();
      await env.CREW_DB.prepare('INSERT INTO oauth_states (state, created_at) VALUES (?, ?)').bind(state, Date.now()).run();
      const redirectUri = `${url.origin}/auth/google/callback`;
      const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
      authUrl.search = new URLSearchParams({ client_id: env.GOOGLE_CLIENT_ID, redirect_uri: redirectUri, response_type: 'code', scope: GOOGLE_SCOPES, access_type: 'offline', prompt: 'consent', state }).toString();
      return json({ url: authUrl.toString() });
    }

    if (url.pathname === '/v1/google/status' && request.method === 'GET') {
      const row = await env.CREW_DB.prepare('SELECT email FROM google_tokens WHERE id = 1').first<{ email?: string }>();
      return json({ connected: !!row, email: row?.email || undefined });
    }

    const approvalMatch = url.pathname.match(/^\/v1\/approvals\/([^/]+)\/approve$/);
    if (approvalMatch && request.method === 'POST') {
      const body = await request.json() as { actionType?: string; payload?: any };
      let externalId = 'approved-without-external-action';
      if (body.actionType === 'gmail_draft') externalId = await createGmailDraft(env, body.payload);
      else if (body.actionType === 'calendar_event') externalId = await createCalendarEvent(env, body.payload);
      await audit(env, 'approval', `${approvalMatch[1]}: ${body.actionType || 'generic'} approved; external=${externalId}`);
      return json({ ok: true, externalId });
    }

    if (url.pathname === '/v1/notifications/test' && request.method === 'POST') {
      await sendBark(env, 'Crew is connected', 'Your AI team can send routine and approval alerts here.', 'Crew test');
      return json({ ok: true });
    }

    if (url.pathname === '/v1/routines/sync' && request.method === 'POST') {
      const body = await request.json() as { routine?: any };
      const routine = body.routine;
      if (!routine?.id || !routine?.name) return json({ error: 'A routine needs an id and name.' }, 400);
      await env.CREW_DB.prepare(`INSERT INTO routines (id, name, description, bot_id, schedule, interval_minutes, enabled, last_run, next_run, run_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET name=excluded.name, description=excluded.description, bot_id=excluded.bot_id, schedule=excluded.schedule, interval_minutes=excluded.interval_minutes, enabled=excluded.enabled, last_run=excluded.last_run, next_run=excluded.next_run, run_count=excluded.run_count`)
        .bind(text(routine.id, 100), text(routine.name, 200), text(routine.description, 1000), text(routine.botId, 100) || 'ace', text(routine.schedule, 100), Number(routine.intervalMinutes) || 1440, routine.enabled ? 1 : 0, Number(routine.lastRun) || null, Number(routine.nextRun) || Date.now() + 60 * 60_000, Number(routine.runCount) || 0).run();
      return json({ ok: true });
    }

    const runMatch = url.pathname.match(/^\/v1\/routines\/([^/]+)\/run$/);
    if (runMatch && request.method === 'POST') {
      const routine = await env.CREW_DB.prepare('SELECT * FROM routines WHERE id = ?').bind(runMatch[1]).first<RoutineRow>();
      if (!routine) return json({ error: 'Routine not found on the backend. Toggle or sync it first.' }, 404);
      ctx.waitUntil(runRoutine(env, routine));
      return json({ ok: true, queued: true });
    }

    return json({ error: 'Not found' }, 404);
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Unexpected backend error.' }, 500);
  }
}

export default {
  fetch: handleRequest,
  async scheduled(_event: ScheduledController, env: Env, ctx: ExecutionContext) {
    const result = await env.CREW_DB.prepare('SELECT * FROM routines WHERE enabled = 1 AND next_run <= ? LIMIT 10').bind(Date.now()).all<RoutineRow>();
    for (const routine of result.results) ctx.waitUntil(runRoutine(env, routine));
  },
} satisfies ExportedHandler<Env>;
