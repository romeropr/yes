import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { CrewProvider, useCrew } from './src/store/CrewContext';
import { colors } from './src/theme';
import { BotOrb } from './src/components/BotOrb';
import { BottomNav, RootTab } from './src/components/BottomNav';
import { HomeScreen } from './src/screens/HomeScreen';
import { TeamScreen } from './src/screens/TeamScreen';
import { ActivityScreen } from './src/screens/ActivityScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { ChatScreen } from './src/screens/ChatScreen';
import { BotDetailScreen } from './src/screens/BotDetailScreen';
import { VoiceScreen } from './src/screens/VoiceScreen';

type Route = { name: 'tabs' } | { name: 'chat'; chatId: string } | { name: 'bot'; botId: string };

function CrewApp() {
  const { state, hydrated } = useCrew();
  const [tab, setTab] = useState<RootTab>('home');
  const [stack, setStack] = useState<Route[]>([{ name: 'tabs' }]);
  const [voiceChatId, setVoiceChatId] = useState<string | null>(null);
  const route = stack[stack.length - 1];
  const push = (next: Route) => setStack((current) => [...current, next]);
  const pop = () => setStack((current) => current.length > 1 ? current.slice(0, -1) : current);
  const changeTab = (next: RootTab) => { setTab(next); setStack([{ name: 'tabs' }]); };
  const openChat = (chatId: string) => push({ name: 'chat', chatId });
  const openBot = (botId: string) => push({ name: 'bot', botId });

  if (!hydrated) {
    return <View style={styles.loading}><BotOrb size={82} active /><Text style={styles.loadingWordmark}>CREW</Text><Text style={styles.loadingText}>Waking up your team…</Text></View>;
  }

  return (
    <View style={styles.viewport}>
      <View style={styles.appShell}>
        <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
          {route.name === 'tabs' && (
            <>
              <View style={styles.tabContent}>
                {tab === 'home' && <HomeScreen onOpenChat={openChat} onOpenActivity={() => changeTab('activity')} onOpenSettings={() => changeTab('settings')} onVoice={(id = 'direct-ace') => setVoiceChatId(id)} />}
                {tab === 'team' && <TeamScreen onOpenChat={openChat} onOpenBot={openBot} />}
                {tab === 'activity' && <ActivityScreen />}
                {tab === 'settings' && <SettingsScreen />}
              </View>
              <BottomNav active={tab} onChange={changeTab} onVoice={() => setVoiceChatId('direct-ace')} activityCount={state.approvals.filter((item) => item.status === 'pending').length} />
            </>
          )}
          {route.name === 'chat' && <ChatScreen chatId={route.chatId} onBack={pop} onVoice={setVoiceChatId} onOpenBot={openBot} />}
          {route.name === 'bot' && <BotDetailScreen botId={route.botId} onBack={pop} onMessage={() => openChat(`direct-${route.botId}`)} />}
          {voiceChatId && <VoiceScreen chatId={voiceChatId} onClose={() => setVoiceChatId(null)} />}
          <StatusBar style="light" />
        </SafeAreaView>
      </View>
    </View>
  );
}

export default function App() {
  return <SafeAreaProvider><CrewProvider><CrewApp /></CrewProvider></SafeAreaProvider>;
}

const styles = StyleSheet.create({
  viewport: { flex: 1, backgroundColor: '#020203', alignItems: 'center' },
  appShell: { flex: 1, width: '100%', maxWidth: 480, backgroundColor: colors.background, borderLeftWidth: StyleSheet.hairlineWidth, borderRightWidth: StyleSheet.hairlineWidth, borderColor: '#19191C', overflow: 'hidden' },
  safe: { flex: 1 },
  tabContent: { flex: 1 },
  loading: { flex: 1, backgroundColor: colors.background, alignItems: 'center', justifyContent: 'center' },
  loadingWordmark: { color: colors.text, fontSize: 16, fontWeight: '800', letterSpacing: 5, marginTop: 20, marginLeft: 5 },
  loadingText: { color: colors.textMuted, fontSize: 11, marginTop: 9 },
});
