module.exports = {
  expo: {
    name: 'Crew',
    slug: 'crew-personal-ai',
    scheme: 'crew',
    version: '1.0.0',
    orientation: 'portrait',
    icon: './assets/icon.png',
    userInterfaceStyle: 'dark',
    backgroundColor: '#060607',
    splash: {
      image: './assets/splash-icon.png',
      resizeMode: 'contain',
      backgroundColor: '#060607',
    },
    ios: {
      supportsTablet: false,
      bundleIdentifier: process.env.IOS_BUNDLE_ID || 'com.crew.personal',
      deploymentTarget: '17.0',
      infoPlist: {
        NSMicrophoneUsageDescription: 'Crew uses the microphone so you can speak to your AI team in hands-free voice mode.',
        NSSpeechRecognitionUsageDescription: 'Crew converts your voice to text so your bots can respond. On-device recognition is requested where supported.',
        UIBackgroundModes: [],
      },
    },
    android: {
      package: 'com.crew.personal',
      adaptiveIcon: {
        backgroundColor: '#060607',
        foregroundImage: './assets/android-icon-foreground.png',
        monochromeImage: './assets/android-icon-monochrome.png',
      },
      predictiveBackGestureEnabled: false,
    },
    web: {
      favicon: './assets/favicon.png',
      bundler: 'metro',
    },
    plugins: [
      ['expo-speech-recognition', {
        microphonePermission: 'Allow Crew to use the microphone for hands-free conversations.',
        speechRecognitionPermission: 'Allow Crew to transcribe your voice so your bots can respond.',
      }],
      'expo-secure-store',
      'expo-web-browser',
    ],
    extra: {
      product: 'Crew',
      autonomy: 'draft-approve',
    },
  },
};
