#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This build needs a macOS runner with Xcode. Use the included GitHub Actions workflow if you do not have a Mac." >&2
  exit 1
fi

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [[ "$NODE_MAJOR" -lt 22 ]]; then
  echo "Node 22 or newer is required by this Expo version." >&2
  exit 1
fi

export IOS_BUNDLE_ID="${IOS_BUNDLE_ID:-com.crew.personal}"
export CI=1
export EXPO_NO_TELEMETRY=1
export COCOAPODS_DISABLE_STATS=1

printf '\n==> Installing JavaScript dependencies\n'
npm ci

printf '\n==> Type-checking and linting Crew\n'
npx tsc --noEmit
npm run lint

printf '\n==> Generating the native iOS project (%s)\n' "$IOS_BUNDLE_ID"
npx expo prebuild --platform ios --clean

printf '\n==> Installing CocoaPods\n'
cd ios
pod install --repo-update
cd "$ROOT_DIR"

if [[ ! -f ios/Crew.xcworkspace/contents.xcworkspacedata ]]; then
  echo "Expected ios/Crew.xcworkspace was not generated." >&2
  exit 1
fi

printf '\n==> Compiling Release arm64 without a signature\n'
rm -rf build/DerivedData
xcodebuild \
  -workspace ios/Crew.xcworkspace \
  -scheme Crew \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath build/DerivedData \
  ARCHS=arm64 \
  ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  CODE_SIGN_ENTITLEMENTS='' \
  DEVELOPMENT_TEAM='' \
  PROVISIONING_PROFILE_SPECIFIER='' \
  build

APP_PATH="build/DerivedData/Build/Products/Release-iphoneos/Crew.app"
EXECUTABLE_PATH="$APP_PATH/Crew"
if [[ ! -d "$APP_PATH" || ! -f "$EXECUTABLE_PATH" ]]; then
  echo "The expected Crew.app or its executable was not produced." >&2
  exit 1
fi

printf '\n==> Verifying the native executable\n'
file "$EXECUTABLE_PATH"
if ! file "$EXECUTABLE_PATH" | grep -q 'Mach-O 64-bit'; then
  echo "Crew does not contain a valid 64-bit Mach-O executable." >&2
  exit 1
fi
plutil -extract CFBundleIdentifier raw "$APP_PATH/Info.plist"
plutil -extract CFBundleShortVersionString raw "$APP_PATH/Info.plist"

printf '\n==> Packaging an unsigned IPA for ESign\n'
rm -rf build/ipa-package
mkdir -p build/ipa-package/Payload
ditto "$APP_PATH" build/ipa-package/Payload/Crew.app
rm -f build/Crew-unsigned.ipa
(cd build/ipa-package && zip -qry ../Crew-unsigned.ipa Payload)

unzip -t build/Crew-unsigned.ipa >/dev/null
printf '\nBuilt: %s/build/Crew-unsigned.ipa\n' "$ROOT_DIR"
printf 'Sign this unsigned IPA with your certificate and provisioning profile in ESign before installing it.\n'
