import { Platform } from 'react-native';

export const colors = {
  background: '#060607',
  surface: '#0D0D0F',
  surfaceRaised: '#131315',
  surfacePressed: '#1A1A1D',
  border: '#242428',
  borderStrong: '#35353B',
  text: '#F5F5F3',
  textSecondary: '#A5A5AD',
  textMuted: '#6F6F78',
  white: '#FFFFFF',
  black: '#000000',
  danger: '#FF6B6B',
  dangerSurface: '#241313',
  overlay: 'rgba(0,0,0,0.78)',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const radius = {
  sm: 10,
  md: 14,
  lg: 18,
  xl: 24,
  pill: 999,
};

export const font = {
  regular: Platform.select({ ios: 'System', default: 'System' }),
  mono: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
};

export const shadow = {
  shadowColor: '#000',
  shadowOpacity: 0.35,
  shadowRadius: 20,
  shadowOffset: { width: 0, height: 10 },
  elevation: 8,
};
