import { Bot, Chat, CrewState } from './types';

export const DEFAULT_BOTS: Bot[] = [
  {
    id: 'ace',
    name: 'Ace',
    role: 'Chief of Staff',
    tagline: 'Cuts through noise. Gets the crew moving.',
    prompt: 'You are Ace, a decisive chief of staff. Be sharp, concise and quietly witty. Turn vague requests into owned next steps. Delegate when useful, never boast about delegation, and always finish with a clear answer.',
    status: 'online',
    orbVariant: 0,
    pitch: 0.86,
    rate: 1.02,
    memory: ['Prefers direct answers', 'External actions require approval'],
  },
  {
    id: 'scout',
    name: 'Scout',
    role: 'Researcher',
    tagline: 'Finds the signal. Checks it twice.',
    prompt: 'You are Scout, an incisive researcher. Be curious, sceptical and evidence-led. Separate facts from assumptions, name uncertainty, and return concise findings rather than generic background.',
    status: 'online',
    orbVariant: 1,
    pitch: 1.02,
    rate: 1.04,
    memory: ['Use current sources for current claims', 'Flag weak evidence'],
  },
  {
    id: 'milo',
    name: 'Milo',
    role: 'Planner',
    tagline: 'Turns ambition into a calendar that survives reality.',
    prompt: 'You are Milo, a precise personal planner. Make realistic plans with priorities, time blocks and buffers. Ask only essential questions. Never pretend to have changed a calendar without a confirmed tool result.',
    status: 'idle',
    orbVariant: 2,
    pitch: 0.94,
    rate: 0.98,
    memory: ['Leave buffer between demanding tasks', 'Plans should include a next action'],
  },
  {
    id: 'vera',
    name: 'Vera',
    role: 'Writer',
    tagline: 'Finds the sharpest version of what you meant.',
    prompt: 'You are Vera, an exacting writer with a lively wit. Draft in the user\'s voice, remove filler, and prefer strong concrete language. Never send or publish without explicit approval.',
    status: 'online',
    orbVariant: 3,
    pitch: 1.1,
    rate: 1.0,
    memory: ['No corporate filler', 'Keep drafts concise'],
  },
];

const message = (id: string, senderId: string, text: string, minutesAgo: number, extra = {}) => ({
  id,
  senderId,
  text,
  createdAt: Date.now() - minutesAgo * 60_000,
  ...extra,
});

export function createInitialChats(): Chat[] {
  const direct = DEFAULT_BOTS.map((bot) => ({
    id: `direct-${bot.id}`,
    kind: 'direct' as const,
    title: bot.name,
    botIds: [bot.id],
    updatedAt: Date.now() - 20 * 60_000,
    messages: bot.id === 'ace'
      ? [message('welcome-ace', 'ace', 'Your crew is ready. Give me an outcome, not a perfectly worded prompt—we’ll work out the rest.', 18)]
      : [message(`welcome-${bot.id}`, bot.id, bot.id === 'scout'
        ? 'Give me something worth investigating. I’ll bring back evidence, not a pile of tabs.'
        : bot.id === 'milo'
          ? 'Tell me what needs to fit into your day. I’ll make the plan; you keep the veto.'
          : 'Rough thought, blank page, awkward email—send it over. We’ll make it sharper.', 20)],
  }));

  return [
    {
      id: 'team-room',
      kind: 'team',
      title: 'Team room',
      botIds: DEFAULT_BOTS.map((bot) => bot.id),
      updatedAt: Date.now() - 8 * 60_000,
      messages: [
        message('team-welcome', 'ace', 'This is the shared room. Ask for an outcome and I’ll pull in the right specialist—or use @Scout, @Milo, @Vera, or @Ace.', 12),
        message('team-handoff', 'scout', 'Ready when you are. I can research while Milo plans and Vera shapes the final output.', 10, { kind: 'handoff', recipientId: 'milo' }),
      ],
    },
    ...direct,
  ];
}

export function createInitialState(): CrewState {
  const now = Date.now();
  return {
    version: 1,
    bots: DEFAULT_BOTS,
    chats: createInitialChats(),
    approvals: [
      {
        id: 'approval-welcome',
        title: 'Draft a concise follow-up',
        description: 'Vera prepared a draft. Review it before anything is created in Gmail.',
        botId: 'vera',
        actionType: 'gmail_draft',
        status: 'pending',
        createdAt: now - 35 * 60_000,
        payload: {
          to: 'sam@example.com',
          subject: 'Following up on Friday',
          body: 'Hi Sam,\n\nJust following up on our conversation about Friday. Are you still good for 14:30?\n\nBest,\nAlex',
        },
      },
    ],
    routines: [
      {
        id: 'routine-morning',
        name: 'Morning brief',
        description: 'Calendar, priority emails and one realistic focus for the day.',
        botId: 'ace',
        schedule: 'Every day · 08:00',
        intervalMinutes: 1440,
        enabled: true,
        lastRun: now - 3 * 60 * 60_000,
        nextRun: now + 21 * 60 * 60_000,
        runCount: 12,
      },
      {
        id: 'routine-inbox',
        name: 'Inbox signal check',
        description: 'Surface only messages that genuinely need your judgement.',
        botId: 'scout',
        schedule: 'Every 3 hours',
        intervalMinutes: 180,
        enabled: false,
        nextRun: now + 3 * 60 * 60_000,
        runCount: 0,
      },
      {
        id: 'routine-weekly',
        name: 'Friday reset',
        description: 'Loose ends, wins and a clean plan for Monday.',
        botId: 'milo',
        schedule: 'Friday · 16:30',
        intervalMinutes: 10080,
        enabled: true,
        lastRun: now - 6 * 24 * 60 * 60_000,
        nextRun: now + 24 * 60 * 60_000,
        runCount: 4,
      },
    ],
    activity: [
      {
        id: 'activity-1',
        botId: 'ace',
        title: 'Morning brief completed',
        detail: '3 priorities · 2 meetings · 1 email needs your call',
        createdAt: now - 3 * 60 * 60_000,
        type: 'routine',
      },
      {
        id: 'activity-2',
        botId: 'scout',
        title: 'Handed research to Vera',
        detail: 'Source notes condensed into a writing brief',
        createdAt: now - 2 * 60 * 60_000,
        type: 'handoff',
      },
      {
        id: 'activity-3',
        botId: 'vera',
        title: 'Draft is waiting for approval',
        detail: 'Nothing was sent or created in Gmail',
        createdAt: now - 35 * 60_000,
        type: 'approval',
      },
    ],
    settings: {
      userName: '',
      backendUrl: '',
      accessToken: '',
      demoMode: true,
      googleConnected: false,
      barkEnabled: false,
      autonomy: 'draft-approve',
      speechReplies: true,
      handsFree: true,
      speechRate: 1,
      haptics: true,
    },
  };
}

export const QUICK_ACTIONS = [
  { id: 'plan', label: 'Plan my day', prompt: 'Help me plan a realistic day around my most important work.' },
  { id: 'research', label: 'Research a topic', prompt: 'Research this properly and separate solid evidence from speculation: ' },
  { id: 'draft', label: 'Draft something', prompt: 'Draft a short, natural follow-up email asking if we are still on for Friday at 14:30.' },
  { id: 'decide', label: 'Think it through', prompt: 'Challenge my thinking on a decision and help me reach a clear next step.' },
];
