import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { createInitialState } from '../data';
import { createDemoResponse } from '../services/demo';
import { executeApproval, runRemoteRoutine, sendLiveChat, syncRoutine } from '../services/api';
import { clearCrewState, loadCrewState, saveAccessToken, saveCrewState } from '../services/storage';
import { ActivityItem, Approval, Bot, CrewSettings, CrewState, Message, Routine, SendResult } from '../types';
import { truncate, uid } from '../utils';

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

interface ActionResult { ok: boolean; error?: string }

interface CrewContextValue {
  state: CrewState;
  hydrated: boolean;
  typingChatId: string | null;
  sendMessage: (chatId: string, text: string) => Promise<SendResult>;
  updateSettings: (patch: Partial<CrewSettings>) => void;
  approve: (id: string) => Promise<ActionResult>;
  dismissApproval: (id: string) => void;
  toggleRoutine: (id: string) => void;
  runRoutineNow: (id: string) => void;
  addBot: (input: Pick<Bot, 'name' | 'role' | 'tagline' | 'prompt'>) => Bot;
  deleteBot: (id: string) => void;
  clearBotMemory: (id: string) => void;
  resetDemo: () => void;
}

const CrewContext = createContext<CrewContextValue | null>(null);

export function CrewProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<CrewState>(() => createInitialState());
  const [hydrated, setHydrated] = useState(false);
  const [typingChatId, setTypingChatId] = useState<string | null>(null);
  const stateRef = useRef(state);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    loadCrewState().then((loaded) => {
      setState(loaded);
      setHydrated(true);
    });
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const timer = setTimeout(() => saveCrewState(state).catch(() => undefined), 250);
    return () => clearTimeout(timer);
  }, [state, hydrated]);

  const appendMessages = useCallback((chatId: string, messages: Message[]) => {
    setState((current) => ({
      ...current,
      chats: current.chats.map((chat) => chat.id === chatId
        ? { ...chat, messages: [...chat.messages, ...messages], updatedAt: Date.now() }
        : chat),
    }));
  }, []);

  const addActivity = useCallback((activity: Omit<ActivityItem, 'id' | 'createdAt'>) => {
    setState((current) => ({
      ...current,
      activity: [{ ...activity, id: uid('activity'), createdAt: Date.now() }, ...current.activity].slice(0, 100),
    }));
  }, []);

  const sendMessage = useCallback(async (chatId: string, rawText: string): Promise<SendResult> => {
    const text = rawText.trim();
    if (!text) return { messages: [], usedLiveBackend: false };
    const snapshot = stateRef.current;
    const chat = snapshot.chats.find((item) => item.id === chatId);
    if (!chat) throw new Error('That conversation no longer exists.');

    const userMessage: Message = { id: uid('user'), senderId: 'user', text, createdAt: Date.now() };
    appendMessages(chatId, [userMessage]);
    setTypingChatId(chatId);
    setState((current) => ({
      ...current,
      bots: current.bots.map((bot) => chat.botIds.includes(bot.id) ? { ...bot, status: 'working' } : bot),
    }));

    let responses: Message[] = [];
    let usedLiveBackend = false;
    let newApproval: Approval | undefined;
    let failure: string | undefined;

    try {
      const live = !snapshot.settings.demoMode && snapshot.settings.backendUrl && snapshot.settings.accessToken;
      if (live) {
        responses = await sendLiveChat(snapshot.settings, {
          chat: { ...chat, messages: [...chat.messages, userMessage] },
          bots: snapshot.bots,
          text,
        });
        usedLiveBackend = true;
      } else {
        await wait(750 + Math.random() * 550);
        const demo = createDemoResponse(chat, snapshot.bots, text);
        responses = demo.messages;
        newApproval = demo.approval;
      }
    } catch (error) {
      failure = error instanceof Error ? error.message : 'The live backend could not be reached.';
    }

    if (failure) {
      responses = [{
        id: uid('error'),
        senderId: 'system',
        kind: 'system',
        text: `Live call failed: ${failure}\n\nYour message is saved. Check Settings → Connection, or switch back to demo mode.`,
        createdAt: Date.now(),
      }];
    }

    appendMessages(chatId, responses);
    if (newApproval) {
      setState((current) => ({ ...current, approvals: [newApproval as Approval, ...current.approvals] }));
    }
    const leadBot = responses.find((message) => message.senderId !== 'system')?.senderId || chat.botIds[0];
    addActivity({
      botId: leadBot,
      title: chat.kind === 'team' ? 'Team completed a pass' : 'Conversation updated',
      detail: newApproval ? 'A new draft is waiting for approval' : truncate(text, 90),
      type: newApproval ? 'approval' : 'message',
    });
    setState((current) => ({
      ...current,
      bots: current.bots.map((bot) => chat.botIds.includes(bot.id)
        ? { ...bot, status: bot.id === 'milo' ? 'idle' : 'online' }
        : bot),
    }));
    setTypingChatId(null);
    return { messages: responses, usedLiveBackend };
  }, [addActivity, appendMessages]);

  const updateSettings = useCallback((patch: Partial<CrewSettings>) => {
    if (Object.prototype.hasOwnProperty.call(patch, 'accessToken')) saveAccessToken(patch.accessToken || '').catch(() => undefined);
    setState((current) => ({ ...current, settings: { ...current.settings, ...patch } }));
  }, []);

  const approve = useCallback(async (id: string): Promise<ActionResult> => {
    const snapshot = stateRef.current;
    const approval = snapshot.approvals.find((item) => item.id === id);
    if (!approval || approval.status !== 'pending') return { ok: false, error: 'This approval is no longer pending.' };
    try {
      const live = !snapshot.settings.demoMode && snapshot.settings.backendUrl && snapshot.settings.accessToken;
      if (live && approval.actionType !== 'generic') {
        await executeApproval(snapshot.settings, approval.id, approval.actionType, approval.payload);
      } else {
        await wait(550);
      }
      setState((current) => ({
        ...current,
        approvals: current.approvals.map((item) => item.id === id ? { ...item, status: 'approved' } : item),
      }));
      addActivity({
        botId: approval.botId,
        title: live ? 'Approved action executed' : 'Demo approval recorded',
        detail: live ? approval.title : 'No external action was taken in demo mode',
        type: 'approval',
      });
      return { ok: true };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : 'Approval failed.' };
    }
  }, [addActivity]);

  const dismissApproval = useCallback((id: string) => {
    setState((current) => ({
      ...current,
      approvals: current.approvals.map((item) => item.id === id ? { ...item, status: 'dismissed' } : item),
    }));
  }, []);

  const toggleRoutine = useCallback((id: string) => {
    const snapshot = stateRef.current;
    const target = snapshot.routines.find((routine) => routine.id === id);
    if (!target) return;
    const updated: Routine = { ...target, enabled: !target.enabled, nextRun: Date.now() + target.intervalMinutes * 60_000 };
    setState((current) => ({
      ...current,
      routines: current.routines.map((routine) => routine.id === id ? updated : routine),
    }));
    const live = !snapshot.settings.demoMode && snapshot.settings.backendUrl && snapshot.settings.accessToken;
    if (live) syncRoutine(snapshot.settings, updated).catch(() => undefined);
  }, []);

  const runRoutineNow = useCallback((id: string) => {
    const routine = stateRef.current.routines.find((item) => item.id === id);
    if (!routine) return;
    setState((current) => ({
      ...current,
      routines: current.routines.map((item) => item.id === id
        ? { ...item, lastRun: Date.now(), nextRun: Date.now() + item.intervalMinutes * 60_000, runCount: item.runCount + 1 }
        : item),
    }));
    const settings = stateRef.current.settings;
    const live = !settings.demoMode && !!settings.backendUrl && !!settings.accessToken;
    if (live) {
      syncRoutine(settings, { ...routine, lastRun: Date.now(), nextRun: Date.now() + routine.intervalMinutes * 60_000, runCount: routine.runCount + 1 })
        .then(() => runRemoteRoutine(settings, routine.id))
        .catch(() => undefined);
    }
    addActivity({
      botId: routine.botId,
      title: `${routine.name} ${live ? 'queued' : 'simulated'}`,
      detail: live ? 'Check Bark for the completion alert' : 'Demo run only—connect the backend for live data and Bark alerts',
      type: 'routine',
    });
  }, [addActivity]);

  const addBot = useCallback((input: Pick<Bot, 'name' | 'role' | 'tagline' | 'prompt'>) => {
    const id = `custom-${Date.now().toString(36)}`;
    const bot: Bot = {
      ...input,
      id,
      status: 'online',
      orbVariant: Math.floor(Math.random() * 4),
      pitch: 0.9 + Math.random() * 0.25,
      rate: 1,
      memory: ['Created by you', 'External actions require approval'],
      isCustom: true,
    };
    setState((current) => ({
      ...current,
      bots: [...current.bots, bot],
      chats: [...current.chats, {
        id: `direct-${id}`,
        kind: 'direct',
        title: bot.name,
        botIds: [id],
        messages: [{ id: uid('welcome'), senderId: id, text: `I’m ${bot.name}. ${bot.tagline}`, createdAt: Date.now() }],
        updatedAt: Date.now(),
      }],
    }));
    return bot;
  }, []);

  const deleteBot = useCallback((id: string) => {
    setState((current) => ({
      ...current,
      bots: current.bots.filter((bot) => bot.id !== id || !bot.isCustom),
      chats: current.chats.filter((chat) => !(chat.kind === 'direct' && chat.botIds.includes(id) && current.bots.find((bot) => bot.id === id)?.isCustom)),
    }));
  }, []);

  const clearBotMemory = useCallback((id: string) => {
    setState((current) => ({
      ...current,
      bots: current.bots.map((bot) => bot.id === id ? { ...bot, memory: [] } : bot),
    }));
  }, []);

  const resetDemo = useCallback(() => {
    clearCrewState().catch(() => undefined);
    setState(createInitialState());
  }, []);

  return (
    <CrewContext.Provider value={{
      state,
      hydrated,
      typingChatId,
      sendMessage,
      updateSettings,
      approve,
      dismissApproval,
      toggleRoutine,
      runRoutineNow,
      addBot,
      deleteBot,
      clearBotMemory,
      resetDemo,
    }}>
      {children}
    </CrewContext.Provider>
  );
}

export function useCrew() {
  const context = useContext(CrewContext);
  if (!context) throw new Error('useCrew must be used inside CrewProvider');
  return context;
}
