import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { createInitialState } from '../data';
import { CrewState } from '../types';

const STATE_KEY = 'crew-state-v1';
const TOKEN_KEY = 'crew-access-token';

export async function getAccessToken() {
  if (Platform.OS === 'web') return AsyncStorage.getItem(TOKEN_KEY);
  return SecureStore.getItemAsync(TOKEN_KEY);
}

export async function saveAccessToken(token: string) {
  if (Platform.OS === 'web') {
    if (token) await AsyncStorage.setItem(TOKEN_KEY, token);
    else await AsyncStorage.removeItem(TOKEN_KEY);
    return;
  }
  if (token) await SecureStore.setItemAsync(TOKEN_KEY, token);
  else await SecureStore.deleteItemAsync(TOKEN_KEY);
}

export async function loadCrewState(): Promise<CrewState> {
  const fallback = createInitialState();
  try {
    const [raw, token] = await Promise.all([AsyncStorage.getItem(STATE_KEY), getAccessToken()]);
    if (!raw) return { ...fallback, settings: { ...fallback.settings, accessToken: token || '' } };
    const saved = JSON.parse(raw) as Partial<CrewState>;
    return {
      ...fallback,
      ...saved,
      bots: Array.isArray(saved.bots) && saved.bots.length ? saved.bots : fallback.bots,
      chats: Array.isArray(saved.chats) && saved.chats.length ? saved.chats : fallback.chats,
      approvals: Array.isArray(saved.approvals) ? saved.approvals : fallback.approvals,
      routines: Array.isArray(saved.routines) ? saved.routines : fallback.routines,
      activity: Array.isArray(saved.activity) ? saved.activity : fallback.activity,
      settings: { ...fallback.settings, ...(saved.settings || {}), accessToken: token || '' },
    };
  } catch {
    return fallback;
  }
}

export async function saveCrewState(state: CrewState) {
  const serialisable: CrewState = {
    ...state,
    settings: { ...state.settings, accessToken: '' },
  };
  await AsyncStorage.setItem(STATE_KEY, JSON.stringify(serialisable));
}

export async function clearCrewState() {
  await AsyncStorage.removeItem(STATE_KEY);
  await saveAccessToken('');
}
