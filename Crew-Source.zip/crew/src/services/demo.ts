import { Approval, Bot, Chat, Message } from '../types';
import { truncate, uid } from '../utils';

const wantsResearch = (text: string) => /research|find out|investigate|compare|latest|news|source|evidence/i.test(text);
const wantsPlan = (text: string) => /plan|schedule|day|week|routine|organise|organize|priority|priorities/i.test(text);
const wantsWriting = (text: string) => /write|draft|email|rewrite|caption|script|blog|message/i.test(text);

function replyFor(bot: Bot, input: string): string {
  const subject = truncate(input.replace(/^(please|can you|could you|help me)\s+/i, ''), 72);
  if (/^(hi|hey|hello|yo)\b/i.test(input.trim())) {
    return bot.id === 'ace'
      ? 'Hey. Give me an outcome, a mess, or a half-formed thought. We’ll take it from there.'
      : `Hey. ${bot.tagline}`;
  }

  if (bot.id === 'scout' || wantsResearch(input)) {
    return `Here’s how I’d attack “${subject}”:\n\n1. Define the exact claim we need to verify.\n2. Check primary sources before commentary.\n3. Compare what the strongest sources agree—and disagree—on.\n4. Return a short verdict with confidence and gaps.\n\nConnect the live backend and I can do the research rather than just look good talking about it.`;
  }
  if (bot.id === 'milo' || wantsPlan(input)) {
    return `Let’s make “${subject}” survivable:\n\n• Now — choose one meaningful outcome.\n• Next — block 45 minutes for the hardest useful step.\n• Then — handle messages and small tasks in one batch.\n• Buffer — leave 15 minutes empty because reality has opinions.\n\nTell me your fixed appointments and available hours, and I’ll turn this into the actual schedule.`;
  }
  if (bot.id === 'vera' || wantsWriting(input)) {
    return `Here’s a clean starting draft:\n\n“Hi Sam,\n\nJust checking we’re still set for Friday at 14:30. If another time works better, send me a couple of options.\n\nBest,\nAlex”\n\nShort, natural, and no ‘I hope this email finds you well.’ You’re welcome.`;
  }
  return `My read on “${subject}”: start with the outcome, then remove anything that doesn’t move it forward.\n\nI’d bring in ${wantsWriting(input) ? 'Vera' : wantsPlan(input) ? 'Milo' : 'Scout'} for a specialist pass, then give you one clear recommendation. For a fully reasoned answer, connect the free live AI backend in Settings.`;
}

function mentionedBot(chat: Chat, bots: Bot[], input: string) {
  const mention = input.match(/@(\w+)/);
  if (mention) {
    const found = bots.find((bot) => bot.name.toLowerCase() === mention[1].toLowerCase());
    if (found) return found;
  }
  if (wantsResearch(input)) return bots.find((bot) => bot.id === 'scout') || bots[0];
  if (wantsPlan(input)) return bots.find((bot) => bot.id === 'milo') || bots[0];
  if (wantsWriting(input)) return bots.find((bot) => bot.id === 'vera') || bots[0];
  return bots.find((bot) => bot.id === 'ace') || bots[0];
}

export function createDemoResponse(chat: Chat, bots: Bot[], input: string) {
  const now = Date.now();
  const roster = bots.filter((bot) => chat.botIds.includes(bot.id));
  const messages: Message[] = [];
  let approval: Approval | undefined;

  if (chat.kind === 'direct') {
    const bot = roster[0] || bots[0];
    messages.push({ id: uid('demo'), senderId: bot.id, text: replyFor(bot, input), createdAt: now });
  } else {
    const specialist = mentionedBot(chat, roster, input);
    const ace = roster.find((bot) => bot.id === 'ace') || roster[0];
    if (specialist.id !== 'ace') {
      messages.push({
        id: uid('handoff'),
        senderId: ace.id,
        recipientId: specialist.id,
        kind: 'handoff',
        text: `${specialist.name}, take the first pass. I’ll keep the answer focused.`,
        createdAt: now,
      });
      messages.push({ id: uid('demo'), senderId: specialist.id, text: replyFor(specialist, input), createdAt: now + 1 });
    } else {
      messages.push({ id: uid('demo'), senderId: ace.id, text: replyFor(ace, input), createdAt: now });
    }
  }

  if (/draft.*email|email.*draft|follow.?up/i.test(input)) {
    approval = {
      id: uid('approval'),
      title: 'Email draft ready for review',
      description: 'Created from your team-room request. Nothing has been sent.',
      botId: 'vera',
      actionType: 'gmail_draft',
      status: 'pending',
      createdAt: now,
      payload: {
        to: 'sam@example.com',
        subject: 'Following up on Friday',
        body: 'Hi Sam,\n\nJust checking we’re still set for Friday at 14:30. If another time works better, send me a couple of options.\n\nBest,\nAlex',
      },
    };
  }

  return { messages, approval };
}
