import { Bot, Chat, CrewSettings, Message } from '../types';
import { uid } from '../utils';

const normaliseBase = (url: string) => url.trim().replace(/\/+$/, '');

async function request<T>(settings: CrewSettings, path: string, init: RequestInit = {}): Promise<T> {
  const base = normaliseBase(settings.backendUrl);
  if (!base) throw new Error('Add your Crew backend URL first.');
  const response = await fetch(`${base}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${settings.accessToken}`,
      ...(init.headers || {}),
    },
  });
  const text = await response.text();
  let data: any = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text }; }
  if (!response.ok) throw new Error(data.error || `Backend returned ${response.status}.`);
  return data as T;
}

export async function testBackend(settings: CrewSettings) {
  return request<{ ok: boolean; ai: boolean; google: boolean; bark: boolean }>(settings, '/v1/health');
}

interface LiveChatInput {
  chat: Chat;
  bots: Bot[];
  text: string;
}

export async function sendLiveChat(settings: CrewSettings, input: LiveChatInput): Promise<Message[]> {
  const primaryBot = input.chat.kind === 'direct' ? input.chat.botIds[0] : 'ace';
  const result = await request<{
    messages: { botId: string; text: string; kind?: 'text' | 'handoff'; recipientId?: string }[];
  }>(settings, '/v1/chat', {
    method: 'POST',
    body: JSON.stringify({
      message: input.text,
      team: input.chat.kind === 'team',
      primaryBot,
      bots: input.bots.filter((bot) => input.chat.botIds.includes(bot.id)),
      history: input.chat.messages.slice(-18).map((message) => ({
        senderId: message.senderId,
        text: message.text,
      })),
    }),
  });
  return result.messages.map((message) => ({
    id: uid('live'),
    senderId: message.botId,
    text: message.text,
    kind: message.kind || 'text',
    recipientId: message.recipientId,
    createdAt: Date.now(),
  }));
}

export async function createGoogleConnectLink(settings: CrewSettings) {
  return request<{ url: string }>(settings, '/v1/google/connect', { method: 'POST', body: '{}' });
}

export async function getGoogleStatus(settings: CrewSettings) {
  return request<{ connected: boolean; email?: string }>(settings, '/v1/google/status');
}

export async function testBark(settings: CrewSettings) {
  return request<{ ok: boolean }>(settings, '/v1/notifications/test', { method: 'POST', body: '{}' });
}

export async function executeApproval(settings: CrewSettings, approvalId: string, actionType: string, payload: unknown) {
  return request<{ ok: boolean; externalId?: string }>(settings, `/v1/approvals/${encodeURIComponent(approvalId)}/approve`, {
    method: 'POST',
    body: JSON.stringify({ actionType, payload }),
  });
}

export async function syncRoutine(settings: CrewSettings, routine: unknown) {
  return request<{ ok: boolean }>(settings, '/v1/routines/sync', {
    method: 'POST',
    body: JSON.stringify({ routine }),
  });
}

export async function runRemoteRoutine(settings: CrewSettings, routineId: string) {
  return request<{ ok: boolean; queued: boolean }>(settings, `/v1/routines/${encodeURIComponent(routineId)}/run`, {
    method: 'POST',
    body: '{}',
  });
}
