import React, { useState } from 'react';
import { KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { ArrowRight, Info, Plus, Users, X } from 'lucide-react-native';
import { useCrew } from '../store/CrewContext';
import { colors } from '../theme';
import { BotOrb } from '../components/BotOrb';
import { StatusPill } from '../components/UI';

interface TeamScreenProps {
  onOpenChat: (id: string) => void;
  onOpenBot: (id: string) => void;
}

export function TeamScreen({ onOpenChat, onOpenBot }: TeamScreenProps) {
  const { state, addBot } = useCrew();
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [tagline, setTagline] = useState('');
  const [prompt, setPrompt] = useState('');

  const close = () => { setCreating(false); setName(''); setRole(''); setTagline(''); setPrompt(''); };
  const create = () => {
    if (!name.trim() || !role.trim()) return;
    const bot = addBot({
      name: name.trim(),
      role: role.trim(),
      tagline: tagline.trim() || 'A custom specialist on your crew.',
      prompt: prompt.trim() || `You are ${name.trim()}, the user's ${role.trim()}. Be concise, capable, and honest about uncertainty. External actions require approval.`,
    });
    close();
    setTimeout(() => onOpenBot(bot.id), 100);
  };

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View><Text style={styles.eyebrow}>YOUR ROSTER</Text><Text style={styles.title}>The crew</Text></View>
          <Pressable style={styles.addButton} onPress={() => setCreating(true)}><Plus size={20} color={colors.black} /></Pressable>
        </View>
        <Text style={styles.intro}>Specialists with their own context. One shared mission.</Text>

        <Pressable style={styles.teamRoom} onPress={() => onOpenChat('team-room')}>
          <View style={styles.teamRoomTop}>
            <View style={styles.teamIcon}><Users size={22} color={colors.black} /></View>
            <View style={styles.teamCopy}><Text style={styles.teamTitle}>Team room</Text><Text style={styles.teamSub}>{state.bots.length} bots · visible handoffs · @mentions</Text></View>
            <ArrowRight size={20} color={colors.black} />
          </View>
          <Text style={styles.teamPrompt}>“Research this, make a plan, then turn it into something I can use.”</Text>
          <View style={styles.teamBots}>{state.bots.slice(0, 6).map((bot) => <View key={bot.id} style={styles.teamBot}><BotOrb size={29} variant={bot.orbVariant} /><Text style={styles.teamBotName}>{bot.name}</Text></View>)}</View>
        </Pressable>

        <View style={styles.rosterHeader}><Text style={styles.rosterTitle}>Direct lines</Text><StatusPill label={`${state.bots.filter((b) => b.status !== 'idle').length} READY`} dark /></View>
        <View style={styles.list}>
          {state.bots.map((bot) => {
            const chat = state.chats.find((item) => item.id === `direct-${bot.id}`);
            const last = chat?.messages.slice(-1)[0];
            return (
              <Pressable key={bot.id} style={styles.botRow} onPress={() => onOpenChat(`direct-${bot.id}`)}>
                <BotOrb variant={bot.orbVariant} size={55} status={bot.status} showStatus />
                <View style={styles.botCopy}>
                  <View style={styles.botTitleRow}><Text style={styles.botName}>{bot.name}</Text><Text style={styles.botRole}>{bot.role}</Text></View>
                  <Text style={styles.lastMessage} numberOfLines={2}>{last?.text || bot.tagline}</Text>
                  <Text style={styles.memory}>{bot.memory.length} memories · {bot.status === 'working' ? 'working now' : 'context saved'}</Text>
                </View>
                <Pressable hitSlop={10} onPress={(event) => { event.stopPropagation(); onOpenBot(bot.id); }} style={styles.info}><Info size={17} color={colors.textMuted} /></Pressable>
              </Pressable>
            );
          })}
        </View>
        <Pressable style={styles.createCard} onPress={() => setCreating(true)}>
          <View style={styles.createIcon}><Plus size={21} color={colors.text} /></View>
          <View style={styles.createCopy}><Text style={styles.createTitle}>Hire a specialist</Text><Text style={styles.createBody}>Name the job. Set the standard. Keep the memory.</Text></View>
          <ArrowRight size={18} color={colors.textMuted} />
        </Pressable>
      </ScrollView>

      <Modal visible={creating} transparent animationType="slide" onRequestClose={close}>
        <KeyboardAvoidingView style={styles.modalWrap} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <Pressable style={styles.backdrop} onPress={close} />
          <View style={styles.sheet}>
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeader}><View><Text style={styles.sheetEyebrow}>NEW TEAMMATE</Text><Text style={styles.sheetTitle}>Hire a specialist</Text></View><Pressable onPress={close}><X size={22} color={colors.textSecondary} /></Pressable></View>
            <Text style={styles.fieldLabel}>NAME</Text><TextInput value={name} onChangeText={setName} placeholder="e.g. Sage" placeholderTextColor={colors.textMuted} style={styles.input} autoFocus />
            <Text style={styles.fieldLabel}>ONE CLEAR JOB</Text><TextInput value={role} onChangeText={setRole} placeholder="e.g. Travel researcher" placeholderTextColor={colors.textMuted} style={styles.input} />
            <Text style={styles.fieldLabel}>SHORT DESCRIPTION</Text><TextInput value={tagline} onChangeText={setTagline} placeholder="What makes this bot useful?" placeholderTextColor={colors.textMuted} style={styles.input} />
            <Text style={styles.fieldLabel}>WORKING INSTRUCTIONS <Text style={styles.optional}>OPTIONAL</Text></Text><TextInput value={prompt} onChangeText={setPrompt} placeholder="Standards, boundaries and how it should work…" placeholderTextColor={colors.textMuted} style={[styles.input, styles.textArea]} multiline />
            <Pressable style={[styles.createButton, (!name.trim() || !role.trim()) && styles.createDisabled]} onPress={create} disabled={!name.trim() || !role.trim()}><Text style={styles.createButtonText}>Add to crew</Text><ArrowRight size={18} color={colors.black} /></Pressable>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 18, paddingTop: 13, paddingBottom: 30 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  eyebrow: { color: colors.textMuted, fontSize: 9, letterSpacing: 1.5, fontWeight: '800' },
  title: { color: colors.text, fontSize: 33, fontWeight: '700', letterSpacing: -1.2, marginTop: 3 },
  addButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center' },
  intro: { color: colors.textSecondary, fontSize: 13, marginTop: 7, marginBottom: 22 },
  teamRoom: { backgroundColor: colors.white, borderRadius: 22, padding: 17 },
  teamRoomTop: { flexDirection: 'row', alignItems: 'center' },
  teamIcon: { width: 43, height: 43, borderRadius: 14, backgroundColor: '#E5E5E3', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  teamCopy: { flex: 1 },
  teamTitle: { color: colors.black, fontSize: 18, fontWeight: '700', letterSpacing: -0.4 },
  teamSub: { color: '#67676D', fontSize: 10, marginTop: 3 },
  teamPrompt: { color: '#343438', fontSize: 15, lineHeight: 21, marginTop: 18, fontWeight: '500' },
  teamBots: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#CACAC7', marginTop: 16, paddingTop: 13 },
  teamBot: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  teamBotName: { color: '#515156', fontSize: 10, fontWeight: '600' },
  rosterHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 26, marginBottom: 8 },
  rosterTitle: { color: colors.text, fontSize: 17, fontWeight: '700' },
  list: { gap: 2 },
  botRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  botCopy: { flex: 1, marginLeft: 13, marginRight: 5 },
  botTitleRow: { flexDirection: 'row', alignItems: 'baseline', gap: 7 },
  botName: { color: colors.text, fontSize: 16, fontWeight: '700' },
  botRole: { color: colors.textMuted, fontSize: 10 },
  lastMessage: { color: colors.textSecondary, fontSize: 12, lineHeight: 17, marginTop: 4 },
  memory: { color: colors.textMuted, fontSize: 9, marginTop: 6 },
  info: { padding: 7 },
  createCard: { flexDirection: 'row', alignItems: 'center', padding: 14, borderWidth: 1, borderColor: colors.border, borderStyle: 'dashed', borderRadius: 18, marginTop: 20 },
  createIcon: { width: 39, height: 39, borderRadius: 20, backgroundColor: colors.surfaceRaised, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  createCopy: { flex: 1 },
  createTitle: { color: colors.text, fontSize: 13, fontWeight: '600' },
  createBody: { color: colors.textMuted, fontSize: 10, marginTop: 3 },
  modalWrap: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { ...StyleSheet.absoluteFill, backgroundColor: colors.overlay },
  sheet: { backgroundColor: '#101012', borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingTop: 10, paddingBottom: 28, borderWidth: 1, borderColor: colors.border },
  sheetHandle: { width: 38, height: 4, borderRadius: 2, backgroundColor: colors.borderStrong, alignSelf: 'center', marginBottom: 17 },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  sheetEyebrow: { color: colors.textMuted, fontSize: 9, fontWeight: '800', letterSpacing: 1.2 },
  sheetTitle: { color: colors.text, fontSize: 25, fontWeight: '700', letterSpacing: -0.7, marginTop: 3 },
  fieldLabel: { color: colors.textSecondary, fontSize: 9, fontWeight: '700', letterSpacing: 0.9, marginTop: 12, marginBottom: 7 },
  optional: { color: colors.textMuted, fontWeight: '400' },
  input: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 13, color: colors.text, fontSize: 14, paddingHorizontal: 14, paddingVertical: 12, outlineStyle: 'none' } as any,
  textArea: { minHeight: 82, textAlignVertical: 'top' },
  createButton: { backgroundColor: colors.white, borderRadius: 15, minHeight: 51, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 20 },
  createDisabled: { opacity: 0.35 },
  createButtonText: { color: colors.black, fontSize: 14, fontWeight: '700' },
});
