import React, { useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Bell, CalendarClock, Check, ChevronDown, ChevronUp, Clock3, Mail, Play, ShieldCheck, X } from 'lucide-react-native';
import { useCrew } from '../store/CrewContext';
import { colors } from '../theme';
import { BotOrb } from '../components/BotOrb';
import { EmptyState } from '../components/UI';
import { CrewSwitch } from '../components/CrewSwitch';
import { formatRelative, formatTime } from '../utils';

type Segment = 'approvals' | 'routines' | 'activity';

export function ActivityScreen() {
  const { state, approve, dismissApproval, toggleRoutine, runRoutineNow } = useCrew();
  const [segment, setSegment] = useState<Segment>('approvals');
  const [expanded, setExpanded] = useState<string | null>(state.approvals[0]?.id || null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const pending = state.approvals.filter((item) => item.status === 'pending');

  const doApprove = async (id: string) => {
    setBusy(id); setError('');
    const result = await approve(id);
    if (!result.ok) setError(result.error || 'Approval failed.');
    setBusy(null);
  };

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>MISSION CONTROL</Text>
        <Text style={styles.title}>Your call, when it matters.</Text>
        <Text style={styles.intro}>Autonomous work moves forward. Consequential actions stop here.</Text>
        <View style={styles.summary}>
          <View style={styles.summaryItem}><Text style={styles.summaryValue}>{pending.length}</Text><Text style={styles.summaryLabel}>pending</Text></View>
          <View style={styles.summaryItem}><Text style={styles.summaryValue}>{state.routines.filter((item) => item.enabled).length}</Text><Text style={styles.summaryLabel}>routines on</Text></View>
          <View style={styles.summaryItem}><Text style={styles.summaryValue}>{state.activity.length}</Text><Text style={styles.summaryLabel}>logged events</Text></View>
        </View>
        <View style={styles.segments}>
          {(['approvals', 'routines', 'activity'] as Segment[]).map((item) => <Pressable key={item} onPress={() => setSegment(item)} style={[styles.segment, segment === item && styles.segmentActive]}><Text style={[styles.segmentText, segment === item && styles.segmentTextActive]}>{item === 'approvals' && pending.length ? `${item[0].toUpperCase()}${item.slice(1)} ${pending.length}` : `${item[0].toUpperCase()}${item.slice(1)}`}</Text></Pressable>)}
        </View>
        {!!error && <View style={styles.error}><Text style={styles.errorText}>{error}</Text></View>}

        {segment === 'approvals' && (
          <View style={styles.section}>
            <View style={styles.safetyNote}><ShieldCheck size={18} color={colors.text} /><Text style={styles.safetyText}>Approval is explicit. A chat message that looks like “yes” never triggers an external action.</Text></View>
            {state.approvals.length === 0 && <EmptyState icon={<Check size={23} color={colors.textSecondary} />} title="Nothing waiting" body="When your crew prepares an external action, it will appear here first." />}
            {state.approvals.map((approval) => {
              const bot = state.bots.find((item) => item.id === approval.botId);
              const isOpen = expanded === approval.id;
              return (
                <View key={approval.id} style={[styles.approvalCard, approval.status !== 'pending' && styles.approvalInactive]}>
                  <Pressable style={styles.approvalHeader} onPress={() => setExpanded(isOpen ? null : approval.id)}>
                    <BotOrb variant={bot?.orbVariant} size={40} />
                    <View style={styles.approvalHeading}><Text style={styles.approvalTitle}>{approval.title}</Text><Text style={styles.approvalMeta}>{bot?.name || 'Crew'} · {formatRelative(approval.createdAt)}</Text></View>
                    {isOpen ? <ChevronUp size={17} color={colors.textMuted} /> : <ChevronDown size={17} color={colors.textMuted} />}
                  </Pressable>
                  {isOpen && (
                    <View style={styles.approvalDetails}>
                      <Text style={styles.approvalDescription}>{approval.description}</Text>
                      <View style={styles.draft}>
                        <View style={styles.draftLabel}><Mail size={13} color={colors.textSecondary} /><Text style={styles.draftLabelText}>{approval.actionType === 'gmail_draft' ? 'GMAIL DRAFT' : 'PROPOSED ACTION'}</Text></View>
                        {!!approval.payload.to && <Text style={styles.draftMeta}>To: {approval.payload.to}</Text>}
                        {!!approval.payload.subject && <Text style={styles.draftSubject}>{approval.payload.subject}</Text>}
                        <Text style={styles.draftBody}>{approval.payload.body || approval.payload.summary || approval.description}</Text>
                      </View>
                      <View style={styles.statusRow}><View style={[styles.statusDot, approval.status === 'approved' && { backgroundColor: colors.white }]} /><Text style={styles.statusText}>{approval.status === 'pending' ? 'Waiting for your decision' : approval.status === 'approved' ? 'Approved' : 'Dismissed'}</Text></View>
                      {approval.status === 'pending' && <View style={styles.actions}><Pressable style={styles.dismissButton} onPress={() => dismissApproval(approval.id)}><X size={16} color={colors.textSecondary} /><Text style={styles.dismissText}>Dismiss</Text></Pressable><Pressable style={styles.approveButton} onPress={() => doApprove(approval.id)} disabled={busy === approval.id}>{busy === approval.id ? <ActivityIndicator size="small" color={colors.black} /> : <Check size={16} color={colors.black} />}<Text style={styles.approveText}>{state.settings.demoMode ? 'Approve demo' : approval.actionType === 'gmail_draft' ? 'Create Gmail draft' : 'Approve action'}</Text></Pressable></View>}
                    </View>
                  )}
                </View>
              );
            })}
          </View>
        )}

        {segment === 'routines' && (
          <View style={styles.section}>
            <View style={styles.safetyNote}><CalendarClock size={18} color={colors.text} /><Text style={styles.safetyText}>Cloud routines can run while Crew is closed. Free-tier schedules are event-driven, not a 24/7 open microphone.</Text></View>
            {state.routines.map((routine) => {
              const bot = state.bots.find((item) => item.id === routine.botId);
              return (
                <View key={routine.id} style={styles.routineCard}>
                  <View style={styles.routineTop}><BotOrb variant={bot?.orbVariant} size={43} active={routine.enabled} /><View style={styles.routineCopy}><Text style={styles.routineName}>{routine.name}</Text><Text style={styles.routineOwner}>{bot?.name} · {routine.schedule}</Text></View><CrewSwitch label={`${routine.enabled ? 'Pause' : 'Enable'} ${routine.name}`} value={routine.enabled} onValueChange={() => toggleRoutine(routine.id)} /></View>
                  <Text style={styles.routineDescription}>{routine.description}</Text>
                  <View style={styles.routineFooter}><View><Text style={styles.routineNext}>{routine.enabled ? `Next ${formatRelative(routine.nextRun)}` : 'Paused'}</Text><Text style={styles.routineRuns}>{routine.runCount} runs{routine.lastRun ? ` · last ${formatRelative(routine.lastRun)}` : ''}</Text></View><Pressable style={styles.runButton} onPress={() => runRoutineNow(routine.id)}><Play size={12} color={colors.text} fill={colors.text} /><Text style={styles.runText}>Run now</Text></Pressable></View>
                </View>
              );
            })}
            <View style={styles.barkNote}><Bell size={17} color={colors.textSecondary} /><Text style={styles.barkText}>Completion and approval alerts arrive through Bark after you connect the backend.</Text></View>
          </View>
        )}

        {segment === 'activity' && (
          <View style={styles.section}>
            {state.activity.length === 0 && <EmptyState icon={<Clock3 size={23} color={colors.textSecondary} />} title="No activity yet" body="Messages, handoffs, approvals and routine runs will be logged here." />}
            {state.activity.map((item, index) => {
              const bot = state.bots.find((botItem) => botItem.id === item.botId);
              return <View key={item.id} style={styles.activityRow}><View style={styles.timeline}><View style={styles.timelineDot} />{index < state.activity.length - 1 && <View style={styles.timelineLine} />}</View><View style={styles.activityContent}><View style={styles.activityTop}><Text style={styles.activityTitle}>{item.title}</Text><Text style={styles.activityTime}>{formatTime(item.createdAt)}</Text></View><Text style={styles.activityBot}>{bot?.name || 'Crew'} · {item.type}</Text><Text style={styles.activityDetail}>{item.detail}</Text></View></View>;
            })}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 18, paddingTop: 15, paddingBottom: 35 },
  eyebrow: { color: colors.textMuted, fontSize: 9, letterSpacing: 1.5, fontWeight: '800' },
  title: { color: colors.text, fontSize: 29, lineHeight: 34, fontWeight: '700', letterSpacing: -1, marginTop: 6, maxWidth: 320 },
  intro: { color: colors.textSecondary, fontSize: 12, lineHeight: 18, marginTop: 7 },
  summary: { flexDirection: 'row', backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 17, paddingVertical: 15, marginTop: 20 },
  summaryItem: { flex: 1, alignItems: 'center' },
  summaryValue: { color: colors.text, fontSize: 22, fontWeight: '700' },
  summaryLabel: { color: colors.textMuted, fontSize: 9, marginTop: 3 },
  segments: { flexDirection: 'row', padding: 3, borderRadius: 12, backgroundColor: colors.surface, marginTop: 18 },
  segment: { flex: 1, height: 34, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  segmentActive: { backgroundColor: colors.surfacePressed },
  segmentText: { color: colors.textMuted, fontSize: 11, fontWeight: '600' },
  segmentTextActive: { color: colors.text },
  section: { marginTop: 15 },
  safetyNote: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, padding: 13, borderRadius: 14, backgroundColor: '#0B0B0D', marginBottom: 13 },
  safetyText: { color: colors.textSecondary, fontSize: 11, lineHeight: 17, flex: 1 },
  error: { padding: 12, borderRadius: 12, backgroundColor: colors.dangerSurface, marginTop: 12 },
  errorText: { color: colors.danger, fontSize: 12 },
  approvalCard: { borderRadius: 18, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.borderStrong, padding: 14, marginBottom: 11 },
  approvalInactive: { opacity: 0.6 },
  approvalHeader: { flexDirection: 'row', alignItems: 'center' },
  approvalHeading: { flex: 1, marginLeft: 11, marginRight: 6 },
  approvalTitle: { color: colors.text, fontSize: 13, fontWeight: '600' },
  approvalMeta: { color: colors.textMuted, fontSize: 10, marginTop: 4 },
  approvalDetails: { marginTop: 14 },
  approvalDescription: { color: colors.textSecondary, fontSize: 12, lineHeight: 18 },
  draft: { marginTop: 12, padding: 13, borderRadius: 13, backgroundColor: '#08080A', borderWidth: 1, borderColor: colors.border },
  draftLabel: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 10 },
  draftLabelText: { color: colors.textMuted, fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  draftMeta: { color: colors.textSecondary, fontSize: 10, marginBottom: 7 },
  draftSubject: { color: colors.text, fontSize: 13, fontWeight: '600', marginBottom: 9 },
  draftBody: { color: colors.textSecondary, fontSize: 12, lineHeight: 19 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12 },
  statusDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.textMuted },
  statusText: { color: colors.textMuted, fontSize: 10 },
  actions: { flexDirection: 'row', gap: 8, marginTop: 13 },
  dismissButton: { height: 43, paddingHorizontal: 14, borderRadius: 12, borderWidth: 1, borderColor: colors.border, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 },
  dismissText: { color: colors.textSecondary, fontSize: 11, fontWeight: '600' },
  approveButton: { flex: 1, height: 43, borderRadius: 12, backgroundColor: colors.white, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  approveText: { color: colors.black, fontSize: 11, fontWeight: '700' },
  routineCard: { padding: 14, borderRadius: 18, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, marginBottom: 11 },
  routineTop: { flexDirection: 'row', alignItems: 'center' },
  routineCopy: { flex: 1, marginLeft: 11, marginRight: 8 },
  routineName: { color: colors.text, fontSize: 14, fontWeight: '600' },
  routineOwner: { color: colors.textMuted, fontSize: 10, marginTop: 4 },
  routineDescription: { color: colors.textSecondary, fontSize: 12, lineHeight: 18, marginTop: 13 },
  routineFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 13, paddingTop: 12, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
  routineNext: { color: colors.textSecondary, fontSize: 10 },
  routineRuns: { color: colors.textMuted, fontSize: 9, marginTop: 3 },
  runButton: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 10, backgroundColor: colors.surfacePressed },
  runText: { color: colors.text, fontSize: 10, fontWeight: '600' },
  barkNote: { flexDirection: 'row', gap: 9, alignItems: 'center', padding: 13 },
  barkText: { color: colors.textMuted, fontSize: 10, lineHeight: 15, flex: 1 },
  activityRow: { flexDirection: 'row', minHeight: 100 },
  timeline: { width: 18, alignItems: 'center' },
  timelineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.textSecondary, marginTop: 5 },
  timelineLine: { width: 1, flex: 1, backgroundColor: colors.border, marginTop: 4 },
  activityContent: { flex: 1, paddingBottom: 20 },
  activityTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  activityTitle: { color: colors.text, fontSize: 13, fontWeight: '600', flex: 1 },
  activityTime: { color: colors.textMuted, fontSize: 9 },
  activityBot: { color: colors.textMuted, fontSize: 9, textTransform: 'capitalize', marginTop: 4 },
  activityDetail: { color: colors.textSecondary, fontSize: 11, lineHeight: 17, marginTop: 7 },
});
