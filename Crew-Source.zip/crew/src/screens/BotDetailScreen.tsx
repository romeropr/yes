import React from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ArrowLeft, Brain, MessageCircle, Trash2 } from 'lucide-react-native';
import { useCrew } from '../store/CrewContext';
import { colors } from '../theme';
import { BotOrb } from '../components/BotOrb';
import { StatusPill } from '../components/UI';

export function BotDetailScreen({ botId, onBack, onMessage }: { botId: string; onBack: () => void; onMessage: () => void }) {
  const { state, clearBotMemory, deleteBot } = useCrew();
  const bot = state.bots.find((item) => item.id === botId);
  if (!bot) return <View style={styles.screen} />;
  const remove = () => {
    Alert.alert('Remove this bot?', `${bot.name} and its direct conversation will be removed.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => { deleteBot(bot.id); onBack(); } },
    ]);
  };
  return (
    <View style={styles.screen}>
      <View style={styles.nav}><Pressable onPress={onBack}><ArrowLeft size={23} color={colors.text} /></Pressable><Text style={styles.navTitle}>Bot profile</Text><View style={{ width: 23 }} /></View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.hero}><BotOrb variant={bot.orbVariant} size={112} active={bot.status === 'working'} /><Text style={styles.name}>{bot.name}</Text><Text style={styles.role}>{bot.role}</Text><View style={styles.status}><StatusPill label={bot.status.toUpperCase()} dark /></View><Text style={styles.tagline}>{bot.tagline}</Text></View>
        <Pressable style={styles.messageButton} onPress={onMessage}><MessageCircle size={18} color={colors.black} /><Text style={styles.messageButtonText}>Message {bot.name}</Text></Pressable>
        <View style={styles.stats}><View style={styles.stat}><Text style={styles.statValue}>{bot.memory.length}</Text><Text style={styles.statLabel}>memories</Text></View><View style={styles.statDivider} /><View style={styles.stat}><Text style={styles.statValue}>{state.chats.find((chat) => chat.id === `direct-${bot.id}`)?.messages.length || 0}</Text><Text style={styles.statLabel}>messages</Text></View><View style={styles.statDivider} /><View style={styles.stat}><Text style={styles.statValue}>{state.activity.filter((item) => item.botId === bot.id).length}</Text><Text style={styles.statLabel}>actions</Text></View></View>
        <View style={styles.section}><Text style={styles.sectionEyebrow}>WORKING BRIEF</Text><Text style={styles.prompt}>{bot.prompt}</Text></View>
        <View style={styles.section}><View style={styles.memoryHeader}><Brain size={17} color={colors.text} /><Text style={styles.sectionTitle}>Working memory</Text></View><Text style={styles.sectionBody}>Durable context kept separate from the other bots. Shared facts still need to be handed off explicitly.</Text><View style={styles.memoryList}>{bot.memory.length ? bot.memory.map((memory, index) => <View key={`${memory}-${index}`} style={styles.memoryRow}><View style={styles.memoryDot} /><Text style={styles.memoryText}>{memory}</Text></View>) : <Text style={styles.noMemory}>No saved memories yet.</Text>}</View>{bot.memory.length > 0 && <Pressable style={styles.clearButton} onPress={() => clearBotMemory(bot.id)}><Text style={styles.clearText}>Clear memory</Text></Pressable>}</View>
        <View style={styles.section}><Text style={styles.sectionEyebrow}>BOUNDARIES</Text><View style={styles.boundary}><Text style={styles.boundaryTitle}>Draft first. You approve.</Text><Text style={styles.sectionBody}>This bot can research and prepare work. Sending, publishing, editing and deleting stay behind your approval.</Text></View></View>
        {bot.isCustom && <Pressable style={styles.deleteButton} onPress={remove}><Trash2 size={16} color={colors.danger} /><Text style={styles.deleteText}>Remove from crew</Text></Pressable>}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  nav: { height: 58, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  navTitle: { color: colors.textSecondary, fontSize: 12, fontWeight: '600' },
  content: { padding: 18, paddingBottom: 35 },
  hero: { alignItems: 'center', paddingTop: 20 },
  name: { color: colors.text, fontSize: 30, fontWeight: '700', letterSpacing: -1, marginTop: 16 },
  role: { color: colors.textSecondary, fontSize: 13, marginTop: 3 },
  status: { marginTop: 11 },
  tagline: { color: colors.textSecondary, fontSize: 14, lineHeight: 20, textAlign: 'center', marginTop: 16, paddingHorizontal: 25 },
  messageButton: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.white, borderRadius: 15, height: 50, marginTop: 22 },
  messageButtonText: { color: colors.black, fontSize: 14, fontWeight: '700' },
  stats: { flexDirection: 'row', alignItems: 'center', paddingVertical: 21, marginTop: 20, borderTopWidth: StyleSheet.hairlineWidth, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  stat: { flex: 1, alignItems: 'center' },
  statValue: { color: colors.text, fontSize: 23, fontWeight: '700' },
  statLabel: { color: colors.textMuted, fontSize: 10, marginTop: 3 },
  statDivider: { width: 1, height: 31, backgroundColor: colors.border },
  section: { marginTop: 25 },
  sectionEyebrow: { color: colors.textMuted, fontSize: 9, fontWeight: '800', letterSpacing: 1.1, marginBottom: 10 },
  sectionTitle: { color: colors.text, fontSize: 16, fontWeight: '700' },
  sectionBody: { color: colors.textSecondary, fontSize: 12, lineHeight: 19 },
  prompt: { color: colors.textSecondary, fontSize: 13, lineHeight: 21, padding: 15, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  memoryHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  memoryList: { marginTop: 14, gap: 2 },
  memoryRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, paddingVertical: 9, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  memoryDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.textSecondary, marginTop: 7 },
  memoryText: { color: colors.text, fontSize: 12, lineHeight: 18, flex: 1 },
  noMemory: { color: colors.textMuted, fontSize: 12, marginTop: 12 },
  clearButton: { alignSelf: 'flex-start', marginTop: 12, paddingVertical: 6 },
  clearText: { color: colors.textSecondary, fontSize: 11, textDecorationLine: 'underline' },
  boundary: { padding: 14, borderRadius: 15, backgroundColor: colors.surface },
  boundaryTitle: { color: colors.text, fontSize: 13, fontWeight: '600', marginBottom: 5 },
  deleteButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, marginTop: 27, padding: 13 },
  deleteText: { color: colors.danger, fontSize: 12, fontWeight: '600' },
});
