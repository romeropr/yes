import React, { useEffect, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, ScrollViewInstance, StyleSheet, Text, View } from 'react-native';
import { ArrowLeft, Info, Mic, Users } from 'lucide-react-native';
import { useCrew } from '../store/CrewContext';
import { colors } from '../theme';
import { BotOrb } from '../components/BotOrb';
import { Composer } from '../components/Composer';
import { MessageBubble } from '../components/MessageBubble';
import { TypingIndicator } from '../components/TypingIndicator';
import { Pill } from '../components/UI';

interface ChatScreenProps {
  chatId: string;
  onBack: () => void;
  onVoice: (chatId: string) => void;
  onOpenBot: (id: string) => void;
}

export function ChatScreen({ chatId, onBack, onVoice, onOpenBot }: ChatScreenProps) {
  const { state, sendMessage, typingChatId } = useCrew();
  const scroll = useRef<ScrollViewInstance>(null);
  const [sending, setSending] = useState(false);
  const chat = state.chats.find((item) => item.id === chatId);
  const primaryBot = state.bots.find((bot) => bot.id === chat?.botIds[0]);

  useEffect(() => { setTimeout(() => scroll.current?.scrollToEnd({ animated: false }), 50); }, [chatId]);

  if (!chat) return <View style={styles.missing}><Text style={styles.missingText}>Conversation not found.</Text></View>;
  const isTeam = chat.kind === 'team';
  const busy = typingChatId === chatId || sending;

  const submit = (text: string) => {
    setSending(true);
    sendMessage(chatId, text).catch(() => undefined).finally(() => setSending(false));
  };

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={0}>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.back}><ArrowLeft size={23} color={colors.text} /></Pressable>
        <Pressable style={styles.identity} onPress={() => !isTeam && primaryBot && onOpenBot(primaryBot.id)} disabled={isTeam}>
          {isTeam ? <View style={styles.teamIcon}><Users size={19} color={colors.text} /></View> : <BotOrb variant={primaryBot?.orbVariant} size={39} status={primaryBot?.status} showStatus />}
          <View style={styles.identityCopy}><Text style={styles.title}>{chat.title}</Text><Text style={styles.subtitle}>{isTeam ? `${chat.botIds.length} teammates · shared room` : `${primaryBot?.role} · ${primaryBot?.status === 'working' ? 'thinking…' : 'ready'}`}</Text></View>
        </Pressable>
        <Pressable onPress={() => onVoice(chatId)} style={styles.voice}><Mic size={20} color={colors.text} /></Pressable>
        {!isTeam && primaryBot && <Pressable onPress={() => onOpenBot(primaryBot.id)} style={styles.info}><Info size={18} color={colors.textMuted} /></Pressable>}
      </View>
      <View style={styles.modeLine}><View style={styles.modeDot} /><Text style={styles.modeText}>{state.settings.demoMode ? 'Demo responses · connect live AI in Settings' : 'Live AI · external actions still need approval'}</Text></View>

      <ScrollView ref={scroll} style={styles.messages} contentContainerStyle={styles.messageContent} onContentSizeChange={() => scroll.current?.scrollToEnd({ animated: true })} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <View style={styles.dayDivider}><View style={styles.dayLine} /><Text style={styles.dayText}>TODAY</Text><View style={styles.dayLine} /></View>
        {chat.messages.map((message) => (
          <MessageBubble key={message.id} message={message} bot={state.bots.find((bot) => bot.id === message.senderId)} recipient={state.bots.find((bot) => bot.id === message.recipientId)} isTeam={isTeam} />
        ))}
        {typingChatId === chatId && <TypingIndicator label={isTeam ? 'Crew is coordinating' : `${primaryBot?.name || 'Bot'} is thinking`} />}
        {chat.messages.length <= 2 && !busy && (
          <View style={styles.suggestions}>
            <Text style={styles.suggestionLabel}>TRY A STARTING POINT</Text>
            <View style={styles.suggestionRow}>
              {(isTeam ? ['Research and plan a launch', 'Draft a follow-up email', 'Challenge my priorities'] : primaryBot?.id === 'scout' ? ['Find the evidence', 'Compare two options'] : primaryBot?.id === 'milo' ? ['Plan my day', 'Build a weekly routine'] : primaryBot?.id === 'vera' ? ['Draft a follow-up email', 'Make this less boring'] : ['Help me decide', 'What should I focus on?']).map((item) => <Pill key={item} label={item} onPress={() => submit(item)} />)}
            </View>
          </View>
        )}
      </ScrollView>
      <Composer placeholder={isTeam ? 'Ask the team or @mention a bot…' : `Message ${primaryBot?.name || 'bot'}…`} onSend={submit} onVoice={() => onVoice(chatId)} busy={busy} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: { minHeight: 65, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  back: { width: 37, height: 42, alignItems: 'center', justifyContent: 'center' },
  identity: { flex: 1, flexDirection: 'row', alignItems: 'center', marginLeft: 3 },
  teamIcon: { width: 39, height: 39, borderRadius: 20, backgroundColor: colors.surfaceRaised, borderWidth: 1, borderColor: colors.borderStrong, alignItems: 'center', justifyContent: 'center' },
  identityCopy: { marginLeft: 10, flex: 1 },
  title: { color: colors.text, fontSize: 15, fontWeight: '700' },
  subtitle: { color: colors.textMuted, fontSize: 10, marginTop: 2 },
  voice: { width: 36, height: 40, alignItems: 'center', justifyContent: 'center' },
  info: { width: 29, height: 40, alignItems: 'center', justifyContent: 'center' },
  modeLine: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingVertical: 6, backgroundColor: '#09090B' },
  modeDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: colors.textMuted },
  modeText: { color: colors.textMuted, fontSize: 9 },
  messages: { flex: 1 },
  messageContent: { paddingHorizontal: 15, paddingTop: 13, paddingBottom: 10 },
  dayDivider: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 22 },
  dayLine: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border, flex: 1 },
  dayText: { color: colors.textMuted, fontSize: 8, fontWeight: '700', letterSpacing: 1.2 },
  suggestions: { marginTop: 6, marginBottom: 12 },
  suggestionLabel: { color: colors.textMuted, fontSize: 8, fontWeight: '700', letterSpacing: 1, marginBottom: 9 },
  suggestionRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  missing: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  missingText: { color: colors.textSecondary },
});
