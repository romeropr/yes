import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Speech from 'expo-speech';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition';
import { AudioLines, Mic, Square, Volume2, VolumeX, X } from 'lucide-react-native';
import { useCrew } from '../store/CrewContext';
import { colors } from '../theme';
import { BotOrb } from '../components/BotOrb';

type Phase = 'idle' | 'listening' | 'thinking' | 'speaking' | 'error';

export function VoiceScreen({ chatId, onClose }: { chatId: string; onClose: () => void }) {
  const { state, sendMessage } = useCrew();
  const chat = state.chats.find((item) => item.id === chatId) || state.chats.find((item) => item.id === 'direct-ace');
  const botId = chat?.kind === 'direct' ? chat.botIds[0] : 'ace';
  const bot = state.bots.find((item) => item.id === botId) || state.bots[0];
  const [phase, setPhase] = useState<Phase>('idle');
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [error, setError] = useState('');
  const [muted, setMuted] = useState(!state.settings.speechReplies);
  const [volume, setVolume] = useState(-2);
  const busy = useRef(false);
  const mounted = useRef(true);
  const phaseRef = useRef(phase);
  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  const stopAudio = useCallback(() => {
    try { ExpoSpeechRecognitionModule.abort(); } catch { /* no active recogniser */ }
    Speech.stop().catch(() => undefined);
  }, []);

  const close = useCallback(() => {
    busy.current = false;
    stopAudio();
    onClose();
  }, [onClose, stopAudio]);

  const startListening = useCallback(async () => {
    if (busy.current) return;
    setError(''); setTranscript('');
    try {
      if (!ExpoSpeechRecognitionModule.isRecognitionAvailable()) {
        setPhase('error');
        setError(Platform.OS === 'web' ? 'Live dictation is not available in this browser preview. Try a sample turn below.' : 'Speech recognition is not available on this device.');
        return;
      }
      const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!permission.granted) {
        setPhase('error');
        setError('Microphone and speech-recognition access are needed for hands-free mode. You can enable them in iOS Settings.');
        return;
      }
      setPhase('listening');
      ExpoSpeechRecognitionModule.start({
        lang: 'en-GB',
        interimResults: true,
        continuous: false,
        requiresOnDeviceRecognition: Platform.OS === 'ios',
        volumeChangeEventOptions: { enabled: true, intervalMillis: 100 },
      });
    } catch (caught) {
      setPhase('error');
      setError(caught instanceof Error ? caught.message : 'Could not start speech recognition.');
    }
  }, []);

  const finishTurn = useCallback(() => {
    busy.current = false;
    if (state.settings.handsFree && mounted.current) setTimeout(() => { if (mounted.current && !busy.current) startListening(); }, 500);
    else setPhase('idle');
  }, [startListening, state.settings.handsFree]);

  const submit = useCallback(async (rawText: string) => {
    const text = rawText.trim();
    if (!text || busy.current) return;
    busy.current = true;
    stopAudio();
    setTranscript(text); setResponse(''); setError(''); setPhase('thinking');
    try {
      const result = await sendMessage(chat?.id || 'direct-ace', text);
      const spoken = result.messages.filter((message) => message.senderId !== 'system' && message.kind !== 'handoff').map((message) => message.text).join('\n\n');
      const reply = spoken || result.messages[0]?.text || 'I saved that, but there was no spoken response.';
      if (!mounted.current) return;
      setResponse(reply);
      if (muted) { setPhase('idle'); finishTurn(); return; }
      setPhase('speaking');
      const conciseSpeech = reply.length > 1100 ? `${reply.slice(0, 1090)}…` : reply;
      Speech.speak(conciseSpeech, {
        language: 'en-GB',
        pitch: bot?.pitch || 1,
        rate: (bot?.rate || 1) * state.settings.speechRate,
        onDone: finishTurn,
        onStopped: () => { if (mounted.current) setPhase('idle'); },
        onError: () => { setPhase('idle'); busy.current = false; },
      });
    } catch (caught) {
      busy.current = false;
      setPhase('error');
      setError(caught instanceof Error ? caught.message : 'That turn failed. Try again.');
    }
  }, [bot, chat, finishTurn, muted, sendMessage, state.settings.speechRate, stopAudio]);

  useSpeechRecognitionEvent('start', () => { if (!busy.current) setPhase('listening'); });
  useSpeechRecognitionEvent('end', () => { if (phaseRef.current === 'listening' && !busy.current) setPhase('idle'); });
  useSpeechRecognitionEvent('result', (event) => {
    const said = event.results[0]?.transcript || '';
    setTranscript(said);
    if (event.isFinal && said.trim() && !busy.current) submit(said);
  });
  useSpeechRecognitionEvent('error', (event) => {
    if (event.error === 'no-speech' || event.error === 'aborted') return;
    setPhase('error');
    setError(event.message || 'Speech recognition stopped. Tap the microphone to retry.');
  });
  useSpeechRecognitionEvent('volumechange', (event) => setVolume(event.value));

  useEffect(() => {
    mounted.current = true;
    if (Platform.OS !== 'web') {
      try { ExpoSpeechRecognitionModule.setCategoryIOS({ category: 'playAndRecord', categoryOptions: ['defaultToSpeaker', 'allowBluetooth'], mode: 'voiceChat' }); } catch { /* optional audio tuning */ }
      const timer = setTimeout(startListening, 350);
      return () => { mounted.current = false; clearTimeout(timer); stopAudio(); };
    }
    return () => { mounted.current = false; stopAudio(); };
  }, [startListening, stopAudio]);

  const micAction = () => {
    if (phase === 'listening') {
      const said = transcript.trim();
      if (said) submit(said);
      else { stopAudio(); setPhase('idle'); }
    } else if (phase === 'speaking') {
      Speech.stop().catch(() => undefined); busy.current = false; setPhase('idle');
    } else if (phase !== 'thinking') startListening();
  };

  const status = phase === 'listening' ? 'Listening…' : phase === 'thinking' ? `${chat?.kind === 'team' ? 'Crew' : bot?.name} is thinking…` : phase === 'speaking' ? `${bot?.name} is speaking` : phase === 'error' ? 'Voice paused' : 'Tap to talk';
  const active = phase === 'listening' || phase === 'thinking' || phase === 'speaking';
  const level = Math.max(0.25, Math.min(1, (volume + 2) / 9));

  return (
    <Modal visible animationType="fade" onRequestClose={close}>
      <SafeAreaView style={styles.screen} edges={['top', 'bottom']}>
        <View style={styles.header}><Pressable onPress={close} style={styles.headerButton}><X size={23} color={colors.text} /></Pressable><View style={styles.headerCentre}><Text style={styles.headerTitle}>{chat?.kind === 'team' ? 'TEAM VOICE' : `${bot?.name.toUpperCase()} VOICE`}</Text><Text style={styles.headerSub}>{state.settings.demoMode ? 'DEMO CONVERSATION' : 'LIVE CONVERSATION'}</Text></View><Pressable onPress={() => { Speech.stop().catch(() => undefined); busy.current = false; setPhase('idle'); setMuted(!muted); }} style={styles.headerButton}>{muted ? <VolumeX size={21} color={colors.textMuted} /> : <Volume2 size={21} color={colors.text} />}</Pressable></View>
        <View style={styles.main}>
          <View style={styles.statusRow}><View style={[styles.statusDot, active && styles.statusDotActive]} /><Text style={styles.status}>{status}</Text></View>
          <View style={styles.orbWrap}><View style={[styles.orbit, active && styles.orbitActive]} /><BotOrb variant={bot?.orbVariant} size={184} active={active} /></View>
          <View style={styles.wave}>
            {Array.from({ length: 23 }).map((_, index) => {
              const base = 5 + ((index * 11) % 19);
              const height = active ? base * (phase === 'listening' ? 0.65 + level : 0.9) : 4;
              return <View key={index} style={[styles.waveBar, { height, opacity: active ? 0.45 + ((index % 4) * 0.14) : 0.2 }]} />;
            })}
          </View>
          <Text style={styles.transcript}>{transcript || (phase === 'listening' ? 'Start speaking. I’ll pick up from there.' : phase === 'idle' ? `Ask ${chat?.kind === 'team' ? 'the whole crew' : bot?.name} anything.` : ' ')}</Text>
          {!!error && <Text style={styles.error}>{error}</Text>}
        </View>
        <View style={styles.bottom}>
          {!!response && <View style={styles.responseCard}><View style={styles.responseLabel}><AudioLines size={14} color={colors.textSecondary} /><Text style={styles.responseLabelText}>{bot?.name.toUpperCase()} · SPOKEN REPLY</Text></View><Text style={styles.responseText} numberOfLines={4}>{response}</Text></View>}
          {(Platform.OS === 'web' || phase === 'error') && <Pressable style={styles.sampleButton} onPress={() => submit('Help me focus on one useful priority today.')} disabled={phase === 'thinking'}><Text style={styles.sampleText}>Try a sample voice turn</Text></Pressable>}
          <View style={styles.controls}><View style={styles.controlSide}><Text style={styles.controlHint}>{state.settings.handsFree ? 'AUTO-LISTEN ON' : 'MANUAL TURNS'}</Text></View><Pressable onPress={micAction} style={[styles.micButton, phase === 'listening' && styles.micButtonActive, phase === 'thinking' && { opacity: 0.5 }]} disabled={phase === 'thinking'}>{phase === 'listening' || phase === 'speaking' ? <Square size={22} color={colors.black} fill={colors.black} /> : <Mic size={29} color={colors.black} />}</Pressable><View style={styles.controlSide}><Pressable onPress={close}><Text style={styles.endText}>END</Text></Pressable></View></View>
          <Text style={styles.privacy}>On-device recognition is requested on iOS. Keep this screen open for continuous hands-free turns.</Text>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#050506', paddingTop: 10 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 13, minHeight: 57 },
  headerButton: { width: 43, height: 43, alignItems: 'center', justifyContent: 'center' },
  headerCentre: { alignItems: 'center' }, headerTitle: { color: colors.text, fontSize: 10, fontWeight: '800', letterSpacing: 1.4 }, headerSub: { color: colors.textMuted, fontSize: 8, letterSpacing: 0.8, marginTop: 3 },
  main: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 25, minHeight: 320 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 7 }, statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.textMuted }, statusDotActive: { backgroundColor: colors.white }, status: { color: colors.textSecondary, fontSize: 12, fontWeight: '600' },
  orbWrap: { alignItems: 'center', justifyContent: 'center', marginTop: 24 }, orbit: { position: 'absolute', width: 216, height: 216, borderRadius: 108, borderWidth: 1, borderColor: '#17171A' }, orbitActive: { borderColor: '#3B3B41' },
  wave: { flexDirection: 'row', alignItems: 'center', gap: 3, height: 30, marginTop: 20 }, waveBar: { width: 2, borderRadius: 1, backgroundColor: colors.white },
  transcript: { color: colors.text, fontSize: 19, lineHeight: 27, fontWeight: '500', letterSpacing: -0.3, textAlign: 'center', marginTop: 20, minHeight: 55 },
  error: { color: colors.textSecondary, fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 12 },
  bottom: { paddingHorizontal: 20, paddingBottom: 18 },
  responseCard: { padding: 14, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, marginBottom: 13 }, responseLabel: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 7 }, responseLabelText: { color: colors.textMuted, fontSize: 8, fontWeight: '800', letterSpacing: 0.9 }, responseText: { color: colors.textSecondary, fontSize: 12, lineHeight: 18 },
  sampleButton: { alignSelf: 'center', paddingVertical: 8, paddingHorizontal: 14, marginBottom: 8 }, sampleText: { color: colors.textSecondary, fontSize: 11, textDecorationLine: 'underline' },
  controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 2 }, controlSide: { width: 90, alignItems: 'center' }, controlHint: { color: colors.textMuted, fontSize: 8, fontWeight: '700', letterSpacing: 0.6 }, endText: { color: colors.textSecondary, fontSize: 10, fontWeight: '700', letterSpacing: 1 },
  micButton: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center' }, micButtonActive: { backgroundColor: '#D4D4D7' },
  privacy: { color: colors.textMuted, fontSize: 8, lineHeight: 12, textAlign: 'center', marginTop: 15, paddingHorizontal: 20 },
});
