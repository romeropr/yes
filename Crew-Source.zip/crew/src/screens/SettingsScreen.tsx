import React, { useState } from 'react';
import { ActivityIndicator, Linking, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import { ArrowRight, Bell, Bot, Check, ChevronRight, Cloud, ExternalLink, KeyRound, Mic, RotateCcw, ShieldCheck, UserRound, Volume2, X } from 'lucide-react-native';
import { useCrew } from '../store/CrewContext';
import { colors } from '../theme';
import { AutonomyMode } from '../types';
import { createGoogleConnectLink, getGoogleStatus, syncRoutine, testBackend, testBark } from '../services/api';
import { CrewSwitch } from '../components/CrewSwitch';

export function SettingsScreen() {
  const { state, updateSettings, resetDemo } = useCrew();
  const [connectionOpen, setConnectionOpen] = useState(false);
  const [url, setUrl] = useState(state.settings.backendUrl);
  const [token, setToken] = useState(state.settings.accessToken);
  const [busy, setBusy] = useState('');
  const [notice, setNotice] = useState('');
  const [resetArmed, setResetArmed] = useState(false);
  const live = !state.settings.demoMode && !!state.settings.backendUrl && !!state.settings.accessToken;

  const flash = (message: string) => { setNotice(message); setTimeout(() => setNotice(''), 4500); };
  const saveAndTest = async () => {
    updateSettings({ backendUrl: url.trim(), accessToken: token.trim(), demoMode: !(url.trim() && token.trim()) });
    if (!url.trim() || !token.trim()) { setConnectionOpen(false); flash('Demo mode enabled. Add both fields when your backend is ready.'); return; }
    setBusy('test');
    try {
      const liveSettings = { ...state.settings, backendUrl: url.trim(), accessToken: token.trim(), demoMode: false };
      const health = await testBackend(liveSettings);
      await Promise.allSettled(state.routines.map((routine) => syncRoutine(liveSettings, routine)));
      updateSettings({ demoMode: false, googleConnected: health.google, barkEnabled: health.bark });
      setConnectionOpen(false);
      flash(`Connected. ${health.ai ? 'Live AI is ready.' : 'Add the AI secret to enable live replies.'}`);
    } catch (error) {
      updateSettings({ demoMode: true });
      flash(error instanceof Error ? error.message : 'Connection failed. Your details are saved; demo mode is active.');
    } finally { setBusy(''); }
  };

  const connectGoogle = async () => {
    if (!live) { setConnectionOpen(true); flash('Connect your live backend before linking Google.'); return; }
    setBusy('google');
    try {
      const { url: authUrl } = await createGoogleConnectLink(state.settings);
      if (Platform.OS === 'web') await Linking.openURL(authUrl);
      else await WebBrowser.openAuthSessionAsync(authUrl, 'crew://google-connected');
      const status = await getGoogleStatus(state.settings);
      updateSettings({ googleConnected: status.connected });
      flash(status.connected ? `Google connected${status.email ? ` as ${status.email}` : ''}.` : 'Google window closed. Finish the consent flow to connect.');
    } catch (error) { flash(error instanceof Error ? error.message : 'Google connection failed.'); }
    finally { setBusy(''); }
  };

  const sendBarkTest = async () => {
    if (!live) { flash('Connect the backend and add your Bark device key first.'); return; }
    setBusy('bark');
    try { await testBark(state.settings); updateSettings({ barkEnabled: true }); flash('Test sent. Check Bark on your iPhone.'); }
    catch (error) { flash(error instanceof Error ? error.message : 'Bark test failed.'); }
    finally { setBusy(''); }
  };

  const setAutonomy = (autonomy: AutonomyMode) => updateSettings({ autonomy });
  const reset = () => {
    if (!resetArmed) { setResetArmed(true); setTimeout(() => setResetArmed(false), 4000); return; }
    resetDemo(); setResetArmed(false); flash('Crew has been reset to the original demo.');
  };

  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>YOUR CONTROL ROOM</Text><Text style={styles.title}>Settings</Text>
        {!!notice && <View style={styles.notice}><Text style={styles.noticeText}>{notice}</Text></View>}

        <View style={styles.profileCard}><View style={styles.profileIcon}><UserRound size={21} color={colors.text} /></View><View style={styles.profileCopy}><Text style={styles.cardEyebrow}>YOUR NAME</Text><TextInput value={state.settings.userName} onChangeText={(userName) => updateSettings({ userName })} placeholder="What should the crew call you?" placeholderTextColor={colors.textMuted} style={styles.nameInput} /></View></View>

        <Text style={styles.sectionTitle}>CONNECTION</Text>
        <View style={styles.card}>
          <View style={styles.settingRow}><View style={styles.settingIcon}><Cloud size={19} color={colors.text} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>AI & automations</Text><Text style={styles.settingBody}>{live ? 'Live backend connected' : 'Demo mode · on-device sample responses'}</Text></View><View style={[styles.connectionDot, live && { backgroundColor: colors.white }]} /></View>
          <Pressable style={styles.primaryButton} onPress={() => { setUrl(state.settings.backendUrl); setToken(state.settings.accessToken); setConnectionOpen(true); }}><Text style={styles.primaryButtonText}>{live ? 'Manage connection' : 'Set up live AI'}</Text><ArrowRight size={16} color={colors.black} /></Pressable>
          <View style={styles.rowDivider} />
          <Pressable style={styles.linkRow} onPress={connectGoogle} disabled={busy === 'google'}><View style={styles.settingIcon}><Bot size={19} color={colors.text} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Gmail + Calendar</Text><Text style={styles.settingBody}>{state.settings.googleConnected ? 'Connected · read and prepare drafts' : 'Connect with Google OAuth'}</Text></View>{busy === 'google' ? <ActivityIndicator size="small" color={colors.text} /> : <ChevronRight size={18} color={colors.textMuted} />}</Pressable>
          <View style={styles.rowDivider} />
          <Pressable style={styles.linkRow} onPress={sendBarkTest} disabled={busy === 'bark'}><View style={styles.settingIcon}><Bell size={19} color={colors.text} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Bark alerts</Text><Text style={styles.settingBody}>{state.settings.barkEnabled ? 'Configured · send a test alert' : 'Test your iPhone notifications'}</Text></View>{busy === 'bark' ? <ActivityIndicator size="small" color={colors.text} /> : <ExternalLink size={16} color={colors.textMuted} />}</Pressable>
        </View>

        <Text style={styles.sectionTitle}>AUTONOMY</Text>
        <View style={styles.card}>
          <View style={styles.autonomyHeader}><ShieldCheck size={19} color={colors.text} /><Text style={styles.autonomyTitle}>Action boundary</Text></View>
          {([
            ['draft-approve', 'Draft & approve', 'Research and prepare automatically. You approve external changes.'],
            ['low-risk', 'Low-risk auto', 'Allow approved routine updates; messages and deletions still wait.'],
            ['read-only', 'Read only', 'Analyse connected apps without preparing changes.'],
          ] as [AutonomyMode, string, string][]).map(([id, title, body]) => <Pressable key={id} style={styles.radioRow} onPress={() => setAutonomy(id)}><View style={[styles.radio, state.settings.autonomy === id && styles.radioActive]}>{state.settings.autonomy === id && <View style={styles.radioInner} />}</View><View style={styles.radioCopy}><Text style={styles.radioTitle}>{title}</Text><Text style={styles.radioBody}>{body}</Text></View></Pressable>)}
        </View>

        <Text style={styles.sectionTitle}>VOICE</Text>
        <View style={styles.card}>
          <View style={styles.toggleRow}><View style={styles.settingIcon}><Volume2 size={19} color={colors.text} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Spoken replies</Text><Text style={styles.settingBody}>Use distinct Apple system voice settings</Text></View><CrewSwitch label="Spoken replies" value={state.settings.speechReplies} onValueChange={(speechReplies) => updateSettings({ speechReplies })} /></View>
          <View style={styles.rowDivider} />
          <View style={styles.toggleRow}><View style={styles.settingIcon}><Mic size={19} color={colors.text} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Hands-free loop</Text><Text style={styles.settingBody}>Listen again after each spoken reply</Text></View><CrewSwitch label="Hands-free loop" value={state.settings.handsFree} onValueChange={(handsFree) => updateSettings({ handsFree })} /></View>
          <View style={styles.rowDivider} />
          <View style={styles.rateRow}><Text style={styles.settingTitle}>Speaking pace</Text><View style={styles.rateOptions}>{[0.85, 1, 1.15].map((rate) => <Pressable key={rate} onPress={() => updateSettings({ speechRate: rate })} style={[styles.rateOption, state.settings.speechRate === rate && styles.rateActive]}><Text style={[styles.rateText, state.settings.speechRate === rate && styles.rateTextActive]}>{rate === 0.85 ? 'Calm' : rate === 1 ? 'Natural' : 'Brisk'}</Text></Pressable>)}</View></View>
          <Text style={styles.footnote}>For privacy and battery life, continuous listening runs only while voice mode is open. iOS does not permit an always-listening “Hey Crew” clone without special system access.</Text>
        </View>

        <Text style={styles.sectionTitle}>DATA</Text>
        <View style={styles.card}>
          <View style={styles.settingRow}><View style={styles.settingIcon}><KeyRound size={19} color={colors.text} /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>Private by architecture</Text><Text style={styles.settingBody}>Chats stay on this device in demo mode. Your access token uses iOS SecureStore.</Text></View></View>
          <Pressable style={styles.resetButton} onPress={reset}><RotateCcw size={15} color={resetArmed ? colors.danger : colors.textSecondary} /><Text style={[styles.resetText, resetArmed && { color: colors.danger }]}>{resetArmed ? 'Tap again to confirm reset' : 'Reset app & demo data'}</Text></Pressable>
        </View>
        <Text style={styles.footer}>CREW 1.0.0 · PERSONAL BUILD</Text><Text style={styles.footerBody}>Free tiers have quotas. No AI provider, hosting service, or speech engine is unlimited.</Text>
      </ScrollView>

      <Modal visible={connectionOpen} transparent animationType="slide" onRequestClose={() => setConnectionOpen(false)}>
        <View style={styles.modalWrap}><Pressable style={styles.backdrop} onPress={() => setConnectionOpen(false)} /><View style={styles.sheet}>
          <View style={styles.sheetHandle} /><View style={styles.sheetHeader}><View><Text style={styles.cardEyebrow}>LIVE BACKEND</Text><Text style={styles.sheetTitle}>Connect your crew</Text></View><Pressable onPress={() => setConnectionOpen(false)}><X size={22} color={colors.textSecondary} /></Pressable></View>
          <Text style={styles.sheetIntro}>Use the included Cloudflare Worker. Keep provider keys in backend secrets—not inside the IPA.</Text>
          <Text style={styles.fieldLabel}>WORKER URL</Text><TextInput value={url} onChangeText={setUrl} placeholder="https://crew-api.you.workers.dev" placeholderTextColor={colors.textMuted} autoCapitalize="none" autoCorrect={false} keyboardType="url" style={styles.input} />
          <Text style={styles.fieldLabel}>PRIVATE ACCESS TOKEN</Text><TextInput value={token} onChangeText={setToken} placeholder="Your own long, random token" placeholderTextColor={colors.textMuted} autoCapitalize="none" autoCorrect={false} secureTextEntry style={styles.input} />
          <View style={styles.setupSteps}><Text style={styles.setupTitle}>SETUP ORDER</Text><Text style={styles.setupText}>1. Create the free Groq and Cloudflare accounts.{'\n'}2. Deploy backend/ and add its secrets with Wrangler.{'\n'}3. Paste the Worker URL and your private token here.{'\n'}4. Connect Google and test Bark.</Text></View>
          <Pressable style={styles.primaryButton} onPress={saveAndTest} disabled={busy === 'test'}>{busy === 'test' ? <ActivityIndicator size="small" color={colors.black} /> : <Check size={17} color={colors.black} />}<Text style={styles.primaryButtonText}>{url && token ? 'Save & test connection' : 'Continue in demo mode'}</Text></Pressable>
          <Pressable style={styles.demoButton} onPress={() => { updateSettings({ demoMode: true }); setConnectionOpen(false); flash('Demo mode enabled. Your connection details are unchanged.'); }}><Text style={styles.demoText}>Use demo mode for now</Text></Pressable>
        </View></View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background }, content: { padding: 18, paddingTop: 15, paddingBottom: 35 },
  eyebrow: { color: colors.textMuted, fontSize: 9, letterSpacing: 1.5, fontWeight: '800' }, title: { color: colors.text, fontSize: 33, fontWeight: '700', letterSpacing: -1.2, marginTop: 3 },
  notice: { padding: 12, borderRadius: 13, backgroundColor: colors.surfaceRaised, borderWidth: 1, borderColor: colors.borderStrong, marginTop: 15 }, noticeText: { color: colors.text, fontSize: 11, lineHeight: 17 },
  profileCard: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 17, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, marginTop: 20 }, profileIcon: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.surfacePressed, alignItems: 'center', justifyContent: 'center', marginRight: 12 }, profileCopy: { flex: 1 }, cardEyebrow: { color: colors.textMuted, fontSize: 8, fontWeight: '800', letterSpacing: 1 }, nameInput: { color: colors.text, fontSize: 14, fontWeight: '600', paddingVertical: 4, marginTop: 2, outlineStyle: 'none' } as any,
  sectionTitle: { color: colors.textMuted, fontSize: 9, fontWeight: '800', letterSpacing: 1.2, marginTop: 25, marginBottom: 9, marginLeft: 2 },
  card: { borderRadius: 18, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, padding: 14 },
  settingRow: { flexDirection: 'row', alignItems: 'center', minHeight: 45 }, settingIcon: { width: 33, height: 39, alignItems: 'flex-start', justifyContent: 'center' }, settingCopy: { flex: 1, paddingRight: 8 }, settingTitle: { color: colors.text, fontSize: 13, fontWeight: '600' }, settingBody: { color: colors.textMuted, fontSize: 10, lineHeight: 15, marginTop: 3 }, connectionDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.textMuted },
  primaryButton: { minHeight: 44, borderRadius: 12, backgroundColor: colors.white, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, marginTop: 13, paddingHorizontal: 13 }, primaryButtonText: { color: colors.black, fontSize: 12, fontWeight: '700' },
  rowDivider: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border, marginVertical: 9 }, linkRow: { flexDirection: 'row', alignItems: 'center', minHeight: 46 },
  autonomyHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 7 }, autonomyTitle: { color: colors.text, fontSize: 14, fontWeight: '700' },
  radioRow: { flexDirection: 'row', alignItems: 'flex-start', paddingVertical: 11 }, radio: { width: 18, height: 18, borderRadius: 9, borderWidth: 1.5, borderColor: colors.textMuted, alignItems: 'center', justifyContent: 'center', marginTop: 1, marginRight: 11 }, radioActive: { borderColor: colors.white }, radioInner: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.white }, radioCopy: { flex: 1 }, radioTitle: { color: colors.text, fontSize: 12, fontWeight: '600' }, radioBody: { color: colors.textMuted, fontSize: 10, lineHeight: 15, marginTop: 3 },
  toggleRow: { flexDirection: 'row', alignItems: 'center', minHeight: 46 }, rateRow: { paddingVertical: 7 }, rateOptions: { flexDirection: 'row', gap: 6, marginTop: 11 }, rateOption: { flex: 1, alignItems: 'center', paddingVertical: 9, borderRadius: 10, backgroundColor: colors.surfaceRaised, borderWidth: 1, borderColor: colors.border }, rateActive: { backgroundColor: colors.white, borderColor: colors.white }, rateText: { color: colors.textSecondary, fontSize: 10, fontWeight: '600' }, rateTextActive: { color: colors.black }, footnote: { color: colors.textMuted, fontSize: 9, lineHeight: 14, marginTop: 11 },
  resetButton: { flexDirection: 'row', alignItems: 'center', gap: 7, marginTop: 12, paddingTop: 12, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border }, resetText: { color: colors.textSecondary, fontSize: 11, fontWeight: '600' },
  footer: { color: colors.textMuted, fontSize: 8, letterSpacing: 1.1, textAlign: 'center', marginTop: 26 }, footerBody: { color: colors.textMuted, fontSize: 9, lineHeight: 14, textAlign: 'center', marginTop: 7, paddingHorizontal: 25 },
  modalWrap: { flex: 1, justifyContent: 'flex-end' }, backdrop: { ...StyleSheet.absoluteFill, backgroundColor: colors.overlay }, sheet: { backgroundColor: '#101012', borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingTop: 10, paddingBottom: 28, borderWidth: 1, borderColor: colors.border }, sheetHandle: { width: 38, height: 4, borderRadius: 2, backgroundColor: colors.borderStrong, alignSelf: 'center', marginBottom: 17 }, sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, sheetTitle: { color: colors.text, fontSize: 25, fontWeight: '700', letterSpacing: -0.7, marginTop: 3 }, sheetIntro: { color: colors.textSecondary, fontSize: 11, lineHeight: 17, marginTop: 12 }, fieldLabel: { color: colors.textSecondary, fontSize: 9, fontWeight: '700', letterSpacing: 0.9, marginTop: 15, marginBottom: 7 }, input: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 13, color: colors.text, fontSize: 13, paddingHorizontal: 14, paddingVertical: 12, outlineStyle: 'none' } as any, setupSteps: { padding: 13, borderRadius: 13, backgroundColor: colors.surface, marginTop: 16 }, setupTitle: { color: colors.textMuted, fontSize: 8, fontWeight: '800', letterSpacing: 1, marginBottom: 7 }, setupText: { color: colors.textSecondary, fontSize: 10, lineHeight: 18 }, demoButton: { alignItems: 'center', padding: 14 }, demoText: { color: colors.textSecondary, fontSize: 11 },
});
