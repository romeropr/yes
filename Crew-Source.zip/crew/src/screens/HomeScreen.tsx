import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ArrowRight, ArrowUpRight, CalendarDays, Check, ChevronRight, Sparkles } from 'lucide-react-native';
import { useCrew } from '../store/CrewContext';
import { colors } from '../theme';
import { greeting, truncate } from '../utils';
import { QUICK_ACTIONS } from '../data';
import { BotOrb } from '../components/BotOrb';
import { SectionHeader, StatusPill } from '../components/UI';
import { Composer } from '../components/Composer';

interface HomeScreenProps {
  onOpenChat: (id: string) => void;
  onOpenActivity: () => void;
  onOpenSettings: () => void;
  onVoice: (chatId?: string) => void;
}

export function HomeScreen({ onOpenChat, onOpenActivity, onOpenSettings, onVoice }: HomeScreenProps) {
  const { state, sendMessage } = useCrew();
  const pending = state.approvals.filter((item) => item.status === 'pending');
  const firstApproval = pending[0];
  const latestTeam = state.chats.find((chat) => chat.id === 'team-room')?.messages.slice(-1)[0];
  const name = state.settings.userName.trim();
  const isLive = !state.settings.demoMode && !!state.settings.backendUrl;

  const quick = (prompt: string) => {
    onOpenChat('direct-ace');
    if (prompt.trim()) setTimeout(() => sendMessage('direct-ace', prompt).catch(() => undefined), 100);
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <View style={styles.wordmarkRow}><BotOrb size={31} variant={0} /><Text style={styles.wordmark}>CREW</Text></View>
        <Pressable onPress={onOpenSettings}><StatusPill label={isLive ? 'LIVE' : 'DEMO'} dark={isLive} /></Pressable>
      </View>

      <View style={styles.greetingBlock}>
        <Text style={styles.greeting}>{greeting()}{name ? `, ${name}` : ''}.</Text>
        <Text style={styles.subtitle}>Four bots. Zero pointless meetings.</Text>
      </View>

      <View style={styles.hero}>
        <Text style={styles.heroTitle}>What are we{'\n'}getting done?</Text>
        <View style={styles.heroComposer}>
          <Composer
            placeholder="Give Ace an outcome…"
            onSend={(text) => { onOpenChat('direct-ace'); setTimeout(() => sendMessage('direct-ace', text).catch(() => undefined), 100); }}
            onVoice={() => onVoice('direct-ace')}
          />
        </View>
        <View style={styles.quickGrid}>
          {QUICK_ACTIONS.map((action) => (
            <Pressable key={action.id} style={styles.quickChip} onPress={() => quick(action.prompt)}>
              <Text style={styles.quickText}>{action.label}</Text>
              <ArrowUpRight size={13} color={colors.textSecondary} />
            </Pressable>
          ))}
        </View>
      </View>

      <SectionHeader title="Your crew" action="View all" onAction={() => onOpenChat('team-room')} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.botCards}>
        {state.bots.slice(0, 5).map((bot) => (
          <Pressable key={bot.id} style={styles.botCard} onPress={() => onOpenChat(`direct-${bot.id}`)}>
            <View style={styles.botCardTop}><BotOrb variant={bot.orbVariant} size={52} status={bot.status} showStatus /><ArrowUpRight size={16} color={colors.textMuted} /></View>
            <Text style={styles.botName}>{bot.name}</Text>
            <Text style={styles.botRole}>{bot.role}</Text>
            <Text style={styles.botTagline} numberOfLines={2}>{bot.tagline}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <SectionHeader title="Happening now" />
      <Pressable style={styles.teamCard} onPress={() => onOpenChat('team-room')}>
        <View style={styles.teamTop}>
          <View style={styles.stack}>
            {state.bots.slice(0, 4).map((bot, index) => <View key={bot.id} style={{ marginLeft: index ? -11 : 0 }}><BotOrb variant={bot.orbVariant} size={34} /></View>)}
          </View>
          <View style={styles.teamLabel}><Text style={styles.teamEyebrow}>TEAM ROOM</Text><Text style={styles.teamTitle}>All hands, no admin.</Text></View>
          <ChevronRight size={18} color={colors.textSecondary} />
        </View>
        <Text style={styles.teamMessage} numberOfLines={2}>{latestTeam ? latestTeam.text : 'Bring the whole crew into one conversation.'}</Text>
        <View style={styles.teamFooter}><View style={styles.liveDot} /><Text style={styles.teamFooterText}>Handoffs and ownership stay visible</Text></View>
      </Pressable>

      {firstApproval && (
        <Pressable style={styles.approvalCard} onPress={onOpenActivity}>
          <View style={styles.approvalIcon}><Check size={18} color={colors.black} /></View>
          <View style={styles.approvalContent}>
            <Text style={styles.approvalEyebrow}>NEEDS YOUR CALL</Text>
            <Text style={styles.approvalTitle}>{firstApproval.title}</Text>
            <Text style={styles.approvalBody} numberOfLines={1}>{firstApproval.payload.subject || firstApproval.description}</Text>
          </View>
          <ArrowRight size={18} color={colors.text} />
        </Pressable>
      )}

      <View style={styles.briefCard}>
        <View style={styles.briefTop}><CalendarDays size={17} color={colors.text} /><Text style={styles.briefTitle}>Today, briefly</Text><Sparkles size={15} color={colors.textMuted} /></View>
        <View style={styles.metrics}>
          <View style={styles.metric}><Text style={styles.metricValue}>{state.routines.filter((r) => r.enabled).length}</Text><Text style={styles.metricLabel}>routines on</Text></View>
          <View style={styles.metricDivider} />
          <View style={styles.metric}><Text style={styles.metricValue}>{pending.length}</Text><Text style={styles.metricLabel}>your call</Text></View>
          <View style={styles.metricDivider} />
          <View style={styles.metric}><Text style={styles.metricValue}>{state.bots.length}</Text><Text style={styles.metricLabel}>bots ready</Text></View>
        </View>
        <Text style={styles.briefFoot}>{truncate(state.activity[0]?.detail || 'Your crew is ready when you are.', 72)}</Text>
      </View>
      <Text style={styles.footerNote}>Demo data stays on this device. Connect services only when you’re ready.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 18, paddingTop: 9, paddingBottom: 30 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  wordmarkRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  wordmark: { color: colors.text, fontSize: 15, fontWeight: '800', letterSpacing: 4 },
  greetingBlock: { marginTop: 31 },
  greeting: { color: colors.textSecondary, fontSize: 14, fontWeight: '500' },
  subtitle: { color: colors.textMuted, fontSize: 12, marginTop: 5 },
  hero: { marginTop: 19 },
  heroTitle: { color: colors.text, fontSize: 35, lineHeight: 39, fontWeight: '700', letterSpacing: -1.5 },
  heroComposer: { marginHorizontal: -14, marginTop: 16 },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 3 },
  quickChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 9, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 999 },
  quickText: { color: colors.textSecondary, fontSize: 11, fontWeight: '600' },
  botCards: { gap: 10, paddingRight: 18 },
  botCard: { width: 166, minHeight: 187, padding: 14, borderRadius: 19, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  botCardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 },
  botName: { color: colors.text, fontSize: 17, fontWeight: '700', letterSpacing: -0.3 },
  botRole: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },
  botTagline: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: 10 },
  teamCard: { backgroundColor: colors.white, borderRadius: 21, padding: 16 },
  teamTop: { flexDirection: 'row', alignItems: 'center' },
  stack: { flexDirection: 'row', marginRight: 12 },
  teamLabel: { flex: 1 },
  teamEyebrow: { color: '#5D5D62', fontSize: 9, fontWeight: '800', letterSpacing: 1.1 },
  teamTitle: { color: colors.black, fontSize: 16, fontWeight: '700', marginTop: 2, letterSpacing: -0.3 },
  teamMessage: { color: '#3F3F43', fontSize: 13, lineHeight: 19, marginTop: 16 },
  teamFooter: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 14, paddingTop: 12, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#C9C9C7' },
  liveDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.black },
  teamFooterText: { color: '#66666B', fontSize: 10, fontWeight: '600' },
  approvalCard: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 18, backgroundColor: colors.surfaceRaised, borderWidth: 1, borderColor: colors.borderStrong, marginTop: 11 },
  approvalIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  approvalContent: { flex: 1, marginRight: 8 },
  approvalEyebrow: { color: colors.textMuted, fontSize: 9, fontWeight: '800', letterSpacing: 0.9 },
  approvalTitle: { color: colors.text, fontSize: 13, fontWeight: '600', marginTop: 4 },
  approvalBody: { color: colors.textSecondary, fontSize: 11, marginTop: 3 },
  briefCard: { marginTop: 11, padding: 16, borderRadius: 19, borderWidth: 1, borderColor: colors.border, backgroundColor: '#0A0A0C' },
  briefTop: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  briefTitle: { color: colors.text, fontSize: 13, fontWeight: '600', flex: 1 },
  metrics: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', marginVertical: 18 },
  metric: { alignItems: 'center', flex: 1 },
  metricValue: { color: colors.text, fontSize: 25, fontWeight: '700', letterSpacing: -0.8 },
  metricLabel: { color: colors.textMuted, fontSize: 10, marginTop: 3 },
  metricDivider: { width: 1, height: 30, backgroundColor: colors.border },
  briefFoot: { color: colors.textSecondary, fontSize: 11, textAlign: 'center' },
  footerNote: { color: colors.textMuted, fontSize: 10, lineHeight: 15, textAlign: 'center', marginTop: 22, paddingHorizontal: 24 },
});
