import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

export function CrewSwitch({ value, onValueChange, label }: { value: boolean; onValueChange: (value: boolean) => void; label: string }) {
  return (
    <Pressable
      onPress={() => onValueChange(!value)}
      style={[styles.track, value ? styles.trackOn : styles.trackOff]}
      accessibilityRole="switch"
      accessibilityLabel={label}
      accessibilityState={{ checked: value }}
      hitSlop={6}
    >
      <View style={[styles.thumb, value ? styles.thumbOn : styles.thumbOff]} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  track: { width: 45, height: 27, borderRadius: 14, padding: 3, justifyContent: 'center', borderWidth: 1 },
  trackOn: { backgroundColor: '#E3E3E1', borderColor: '#E3E3E1', alignItems: 'flex-end' },
  trackOff: { backgroundColor: '#242428', borderColor: '#303036', alignItems: 'flex-start' },
  thumb: { width: 19, height: 19, borderRadius: 10 },
  thumbOn: { backgroundColor: '#080809' },
  thumbOff: { backgroundColor: '#85858D' },
});
