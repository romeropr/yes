import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ArrowRight, CheckCheck } from 'lucide-react-native';
import { Bot, Message } from '../types';
import { colors } from '../theme';
import { BotOrb } from './BotOrb';
import { formatTime } from '../utils';

interface MessageBubbleProps {
  message: Message;
  bot?: Bot;
  recipient?: Bot;
  isTeam: boolean;
}

export function MessageBubble({ message, bot, recipient, isTeam }: MessageBubbleProps) {
  if (message.kind === 'system' || message.senderId === 'system') {
    return <View style={styles.system}><Text style={styles.systemText}>{message.text}</Text></View>;
  }
  if (message.kind === 'handoff') {
    return (
      <View style={styles.handoff}>
        <View style={styles.handoffTop}>
          <Text style={styles.handoffLabel}>{bot?.name || 'Bot'}</Text>
          <ArrowRight size={13} color={colors.textMuted} />
          <Text style={styles.handoffLabel}>{recipient?.name || 'Crew'}</Text>
        </View>
        <Text style={styles.handoffText}>{message.text}</Text>
      </View>
    );
  }
  if (message.senderId === 'user') {
    return (
      <View style={styles.userWrap}>
        <View style={styles.userBubble}><Text style={styles.userText}>{message.text}</Text></View>
        <Text style={styles.timeRight}>{formatTime(message.createdAt)}</Text>
      </View>
    );
  }
  return (
    <View style={styles.botRow}>
      {isTeam && <View style={styles.smallOrb}><BotOrb variant={bot?.orbVariant || 0} size={30} active={message.pending} /></View>}
      <View style={styles.botContent}>
        {isTeam && <Text style={styles.botName}>{bot?.name || 'Crew'} <Text style={styles.botRole}>{bot?.role}</Text></Text>}
        <Text style={styles.botText}>{message.text}</Text>
        <View style={styles.metaRow}>
          <Text style={styles.time}>{formatTime(message.createdAt)}</Text>
          {message.pending && <CheckCheck size={12} color={colors.textMuted} />}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  userWrap: { alignItems: 'flex-end', marginLeft: 48, marginBottom: 18 },
  userBubble: { backgroundColor: colors.white, borderRadius: 20, borderBottomRightRadius: 5, paddingHorizontal: 16, paddingVertical: 12 },
  userText: { color: colors.black, fontSize: 15, lineHeight: 21, fontWeight: '400' },
  timeRight: { color: colors.textMuted, fontSize: 10, marginTop: 5, marginRight: 3 },
  botRow: { flexDirection: 'row', marginBottom: 21, paddingRight: 18 },
  smallOrb: { marginRight: 10, marginTop: 2 },
  botContent: { flex: 1 },
  botName: { color: colors.text, fontSize: 12, fontWeight: '700', marginBottom: 6 },
  botRole: { color: colors.textMuted, fontWeight: '400', fontSize: 11 },
  botText: { color: '#E7E7E8', fontSize: 15, lineHeight: 23, letterSpacing: 0.02 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 7 },
  time: { color: colors.textMuted, fontSize: 10 },
  system: { alignSelf: 'center', maxWidth: '94%', borderRadius: 12, padding: 11, marginBottom: 18, backgroundColor: colors.surfaceRaised, borderWidth: 1, borderColor: colors.border },
  systemText: { color: colors.textSecondary, fontSize: 12, lineHeight: 18, textAlign: 'center' },
  handoff: { marginLeft: 14, marginRight: 28, marginBottom: 19, padding: 12, borderRadius: 13, backgroundColor: '#0C0C0E', borderWidth: 1, borderColor: colors.border, borderStyle: 'dashed' },
  handoffTop: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 6 },
  handoffLabel: { color: colors.textMuted, fontSize: 10, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.7 },
  handoffText: { color: colors.textSecondary, fontSize: 13, lineHeight: 19 },
});
