import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ChevronRight } from 'lucide-react-native';
import { colors } from '../theme';

export function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <View style={styles.sectionHeader}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {action && <Pressable onPress={onAction} style={styles.action}><Text style={styles.actionText}>{action}</Text><ChevronRight size={14} color={colors.textSecondary} /></Pressable>}
    </View>
  );
}

export function Pill({ label, active = false, onPress }: { label: string; active?: boolean; onPress?: () => void }) {
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={[styles.pill, active && styles.pillActive]}>
      <Text style={[styles.pillText, active && styles.pillTextActive]}>{label}</Text>
    </Pressable>
  );
}

export function StatusPill({ label, dark = false }: { label: string; dark?: boolean }) {
  return <View style={[styles.statusPill, dark && styles.statusPillDark]}><View style={[styles.statusDot, dark && { backgroundColor: colors.white }]} /><Text style={[styles.statusText, dark && { color: colors.white }]}>{label}</Text></View>;
}

export function Divider() { return <View style={styles.divider} />; }

export function EmptyState({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return <View style={styles.empty}><View style={styles.emptyIcon}>{icon}</View><Text style={styles.emptyTitle}>{title}</Text><Text style={styles.emptyBody}>{body}</Text></View>;
}

const styles = StyleSheet.create({
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, marginTop: 25 },
  sectionTitle: { color: colors.text, fontSize: 17, fontWeight: '700', letterSpacing: -0.3 },
  action: { flexDirection: 'row', alignItems: 'center', gap: 1 },
  actionText: { color: colors.textSecondary, fontSize: 12 },
  pill: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface },
  pillActive: { backgroundColor: colors.white, borderColor: colors.white },
  pillText: { color: colors.textSecondary, fontSize: 12, fontWeight: '600' },
  pillTextActive: { color: colors.black },
  statusPill: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 9, paddingVertical: 5, borderRadius: 999, backgroundColor: '#E8E8E6' },
  statusPillDark: { backgroundColor: colors.surfaceRaised, borderWidth: 1, borderColor: colors.border },
  statusDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.black },
  statusText: { fontSize: 10, fontWeight: '700', color: colors.black },
  divider: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border, marginVertical: 4 },
  empty: { alignItems: 'center', paddingHorizontal: 38, paddingVertical: 50 },
  emptyIcon: { width: 50, height: 50, borderRadius: 25, backgroundColor: colors.surfaceRaised, alignItems: 'center', justifyContent: 'center', marginBottom: 15 },
  emptyTitle: { color: colors.text, fontSize: 17, fontWeight: '700', marginBottom: 7 },
  emptyBody: { color: colors.textSecondary, fontSize: 13, lineHeight: 20, textAlign: 'center' },
});
