import React, { useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { ArrowUp, Mic } from 'lucide-react-native';
import { colors } from '../theme';

interface ComposerProps {
  placeholder?: string;
  onSend: (text: string) => void;
  onVoice: () => void;
  busy?: boolean;
  autoFocus?: boolean;
}

export function Composer({ placeholder = 'Message your crew…', onSend, onVoice, busy = false, autoFocus = false }: ComposerProps) {
  const [text, setText] = useState('');
  const submit = () => {
    if (!text.trim() || busy) return;
    onSend(text);
    setText('');
  };
  return (
    <View style={styles.wrap}>
      <View style={styles.inputRow}>
        <TextInput
          value={text}
          onChangeText={setText}
          placeholder={placeholder}
          placeholderTextColor={colors.textMuted}
          style={styles.input}
          multiline
          maxLength={6000}
          autoFocus={autoFocus}
          onSubmitEditing={submit}
          blurOnSubmit
        />
        {text.trim() ? (
          <Pressable onPress={submit} style={[styles.send, busy && styles.disabled]} disabled={busy} accessibilityLabel="Send message">
            {busy ? <ActivityIndicator size="small" color={colors.black} /> : <ArrowUp size={20} color={colors.black} strokeWidth={2.4} />}
          </Pressable>
        ) : (
          <Pressable onPress={onVoice} style={styles.mic} accessibilityLabel="Speak to your crew">
            <Mic size={21} color={colors.text} strokeWidth={1.8} />
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingHorizontal: 14, paddingTop: 8, paddingBottom: 10, backgroundColor: colors.background },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: colors.surfaceRaised,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    borderRadius: 24,
    paddingLeft: 17,
    paddingRight: 6,
    paddingVertical: 6,
    minHeight: 52,
  },
  input: { flex: 1, color: colors.text, fontSize: 15, lineHeight: 20, maxHeight: 120, paddingTop: 9, paddingBottom: 8, paddingRight: 10, outlineStyle: 'none' } as any,
  mic: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  send: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center' },
  disabled: { opacity: 0.6 },
});
