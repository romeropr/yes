import React, { useEffect, useState } from 'react';
import { Animated, Easing, StyleSheet, View } from 'react-native';
import Svg, { Circle, Defs, Ellipse, RadialGradient, Stop } from 'react-native-svg';
import { BotStatus } from '../types';
import { colors } from '../theme';

interface BotOrbProps {
  variant?: number;
  size?: number;
  status?: BotStatus;
  active?: boolean;
  showStatus?: boolean;
}

export function BotOrb({ variant = 0, size = 54, status = 'online', active = false, showStatus = false }: BotOrbProps) {
  const [spin] = useState(() => new Animated.Value(0));
  const [pulse] = useState(() => new Animated.Value(0));

  useEffect(() => {
    const spinLoop = Animated.loop(Animated.timing(spin, {
      toValue: 1,
      duration: active ? 4200 : 12000 + variant * 900,
      easing: Easing.linear,
      useNativeDriver: true,
    }));
    const pulseLoop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: active ? 650 : 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: active ? 650 : 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    spinLoop.start();
    pulseLoop.start();
    return () => { spinLoop.stop(); pulseLoop.stop(); };
  }, [active, pulse, spin, variant]);

  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.96, active ? 1.08 : 1.035] });
  const gid = `orb-${variant}-${size}-${active ? 'a' : 'n'}`;
  const tilt = [0.72, 0.5, 0.82, 0.62][variant % 4];

  return (
    <View style={{ width: size, height: size }}>
      <Animated.View style={[styles.orb, { transform: [{ scale }] }]}>
        <Animated.View style={{ transform: [{ rotate }] }}>
          <Svg width={size} height={size} viewBox="0 0 100 100">
            <Defs>
              <RadialGradient id={gid} cx="36%" cy="30%" r="72%">
                <Stop offset="0" stopColor="#FFFFFF" stopOpacity="1" />
                <Stop offset="0.28" stopColor="#D9D9DE" stopOpacity="0.96" />
                <Stop offset="0.62" stopColor="#6E6E78" stopOpacity="0.9" />
                <Stop offset="0.86" stopColor="#202024" stopOpacity="0.98" />
                <Stop offset="1" stopColor="#080809" stopOpacity="1" />
              </RadialGradient>
            </Defs>
            <Circle cx="50" cy="50" r="47" fill="#0A0A0C" stroke="#34343A" strokeWidth="1" />
            <Circle cx="50" cy="50" r={variant % 2 ? 39 : 41} fill={`url(#${gid})`} />
            <Ellipse cx="50" cy="50" rx="46" ry={46 * tilt} fill="none" stroke="#F5F5F3" strokeOpacity="0.42" strokeWidth="1.3" transform={`rotate(${variant * 37 + 18} 50 50)`} />
            <Ellipse cx="50" cy="50" rx="34" ry="12" fill="none" stroke="#FFFFFF" strokeOpacity="0.26" strokeWidth="1" transform={`rotate(${-variant * 24 - 28} 50 50)`} />
            <Circle cx={37 + variant * 3} cy={32 + variant} r="5" fill="#FFFFFF" fillOpacity="0.72" />
          </Svg>
        </Animated.View>
      </Animated.View>
      {showStatus && (
        <View style={[styles.status, { borderColor: colors.background, backgroundColor: status === 'working' ? colors.white : status === 'online' ? '#BFC0C5' : '#55555D' }]} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  orb: { flex: 1 },
  status: {
    position: 'absolute',
    right: 1,
    bottom: 3,
    width: 11,
    height: 11,
    borderRadius: 6,
    borderWidth: 2,
  },
});
