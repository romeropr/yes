import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Activity, Home, Settings, Users, Mic } from 'lucide-react-native';
import { colors } from '../theme';

export type RootTab = 'home' | 'team' | 'activity' | 'settings';

interface BottomNavProps {
  active: RootTab;
  onChange: (tab: RootTab) => void;
  onVoice: () => void;
  activityCount?: number;
}

const items = [
  { id: 'home' as const, label: 'Home', Icon: Home },
  { id: 'team' as const, label: 'Crew', Icon: Users },
  { id: 'voice' as const, label: 'Voice', Icon: Mic },
  { id: 'activity' as const, label: 'Activity', Icon: Activity },
  { id: 'settings' as const, label: 'Settings', Icon: Settings },
];

export function BottomNav({ active, onChange, onVoice, activityCount = 0 }: BottomNavProps) {
  return (
    <View style={styles.container}>
      {items.map(({ id, label, Icon }) => {
        if (id === 'voice') {
          return (
            <Pressable key={id} onPress={onVoice} style={styles.voiceItem} accessibilityLabel="Open hands-free voice">
              <View style={styles.voiceButton}><Icon size={23} color={colors.black} strokeWidth={2.2} /></View>
            </Pressable>
          );
        }
        const selected = active === id;
        return (
          <Pressable key={id} onPress={() => onChange(id)} style={styles.item} accessibilityRole="tab" accessibilityState={{ selected }}>
            <View>
              <Icon size={21} color={selected ? colors.text : colors.textMuted} strokeWidth={selected ? 2.2 : 1.7} />
              {id === 'activity' && activityCount > 0 && <View style={styles.badge}><Text style={styles.badgeText}>{Math.min(activityCount, 9)}</Text></View>}
            </View>
            <Text style={[styles.label, selected && styles.labelActive]}>{label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 76,
    flexDirection: 'row',
    alignItems: 'center',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
    backgroundColor: '#09090B',
    paddingHorizontal: 6,
    paddingBottom: 4,
  },
  item: { flex: 1, height: 64, alignItems: 'center', justifyContent: 'center', gap: 5 },
  label: { fontSize: 10, color: colors.textMuted, fontWeight: '500' },
  labelActive: { color: colors.text },
  voiceItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  voiceButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.white,
    marginTop: -17,
    borderWidth: 5,
    borderColor: '#09090B',
  },
  badge: { position: 'absolute', top: -6, right: -10, minWidth: 15, height: 15, borderRadius: 8, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3 },
  badgeText: { color: colors.black, fontSize: 9, fontWeight: '800' },
});
