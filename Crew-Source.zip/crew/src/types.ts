export type BotStatus = 'online' | 'working' | 'idle';
export type ChatKind = 'direct' | 'team';
export type ApprovalStatus = 'pending' | 'approved' | 'dismissed';
export type AutonomyMode = 'draft-approve' | 'low-risk' | 'read-only';

export interface Bot {
  id: string;
  name: string;
  role: string;
  tagline: string;
  prompt: string;
  status: BotStatus;
  orbVariant: number;
  pitch: number;
  rate: number;
  memory: string[];
  isCustom?: boolean;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  createdAt: number;
  kind?: 'text' | 'handoff' | 'system';
  recipientId?: string;
  pending?: boolean;
  failed?: boolean;
}

export interface Chat {
  id: string;
  kind: ChatKind;
  title: string;
  botIds: string[];
  messages: Message[];
  updatedAt: number;
  unread?: number;
}

export interface Approval {
  id: string;
  title: string;
  description: string;
  botId: string;
  actionType: 'gmail_draft' | 'calendar_event' | 'generic';
  status: ApprovalStatus;
  createdAt: number;
  payload: {
    to?: string;
    subject?: string;
    body?: string;
    start?: string;
    end?: string;
    summary?: string;
  };
}

export interface Routine {
  id: string;
  name: string;
  description: string;
  botId: string;
  schedule: string;
  intervalMinutes: number;
  enabled: boolean;
  lastRun?: number;
  nextRun: number;
  runCount: number;
}

export interface ActivityItem {
  id: string;
  botId: string;
  title: string;
  detail: string;
  createdAt: number;
  type: 'handoff' | 'routine' | 'approval' | 'message' | 'system';
}

export interface CrewSettings {
  userName: string;
  backendUrl: string;
  accessToken: string;
  demoMode: boolean;
  googleConnected: boolean;
  barkEnabled: boolean;
  autonomy: AutonomyMode;
  speechReplies: boolean;
  handsFree: boolean;
  speechRate: number;
  haptics: boolean;
}

export interface CrewState {
  version: number;
  bots: Bot[];
  chats: Chat[];
  approvals: Approval[];
  routines: Routine[];
  activity: ActivityItem[];
  settings: CrewSettings;
}

export interface SendResult {
  messages: Message[];
  usedLiveBackend: boolean;
}
