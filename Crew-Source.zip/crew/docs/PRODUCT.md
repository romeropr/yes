# Crew product brief

## Agreed direction

| Area | Decision |
|---|---|
| Platform | iOS 26 iPhone app, sideloaded with ESign |
| Concept | Grok Bot-inspired team of persistent specialist bots |
| User | Private single-user product |
| Visuals | Dark, minimal, pure monochrome |
| Identities | Animated abstract orbital bots |
| Personality | Sharp and witty, not hostile |
| Starter roster | Ace (chief), Scout (research), Milo (planning), Vera (writing) |
| Interaction | Chief + direct chats + visible team room and @mentions |
| Voice | Continuous hands-free turn-taking while voice mode is open |
| Work style | Google-connected work, drafts before consequential actions |
| Background | Autonomous scheduled routines with Bark alerts |
| First integration | Gmail + Google Calendar |
| Budget | Strictly free-tier starting architecture |
| Build | No local build tools; cloud macOS workflow producing an unsigned IPA |

## Implemented in this source

- Responsive React Native/Expo app with a native iOS configuration.
- Persistent local bot roster, conversations, memories, approvals, routines and activity.
- Custom specialist creation and deletion.
- Demo orchestration with specialist selection, team handoffs and draft creation.
- Live backend orchestration with separate system prompts and two-step team synthesis.
- Apple speech recognition and text-to-speech voice loop.
- Secure-on-iOS access-token storage.
- Backend bearer authentication and provider-secret isolation.
- Google OAuth state validation, token refresh and backend-only token storage.
- Gmail draft and calendar event approval endpoints.
- D1-backed routine sync, scheduled execution, Google briefing collection and Bark alerts.
- Repeatable macOS unsigned-IPA build/package workflow.
- Repeatable backend migration/secrets/deployment workflow.

## Deliberate v1 boundaries

- No always-on cloud computer or arbitrary account/browser control.
- No invisible always-listening wake word or background microphone mode.
- No automatic email sending or publishing.
- No silent fallback from a failed live request to a made-up “live” result.
- No native Crew APNs entitlement; Bark handles remote alerts.
- Routine precision is bounded by the 15-minute cloud scheduler and provider availability.
- Free provider models and quotas are configuration, not a promise of unlimited use.

## Natural next iterations

1. Add editable routine schedules and a routine builder.
2. Add structured AI-produced approvals with recipient confirmation.
3. Add explicit read/write rules per Google resource.
4. Add Notion, Slack or GitHub through the same backend connector pattern.
5. Add source-backed web research with visible citations.
6. Add encrypted/self-hosted Bark notifications and a self-hosted sync option.
7. Add per-bot voice selection from the actual voices installed on the iPhone.
