# Crew: no-Mac setup guide

This path uses two manual GitHub Actions workflows: one compiles the iPhone app, and one deploys the private backend. You do not need Xcode, a Mac, or a paid Apple Developer account for the unsigned build. You **do** need your own working ESign certificate/provisioning profile to install it.

> Never paste passwords, API keys, certificates, provisioning profiles, Google refresh tokens, or Bark keys into chat or source files. Use GitHub Secrets, Cloudflare secrets, and the app’s secure settings field.

## 1. Prepare the source repository

1. Create a GitHub account if you do not have one.
2. Create a repository and add the extracted Crew source. Do not include `node_modules`, `dist`, `build`, `.env`, or `backend/.dev.vars`.
3. Open **Actions** and enable workflows if GitHub asks.
4. Public repositories currently have the simplest free Actions path. Private-repository minutes and macOS multipliers depend on your GitHub plan; check your account if cost is a hard £0 requirement. No credentials are needed in the source.

If you connect GitHub to your assistant workspace, this source can also be pushed for you instead of uploaded manually.

## 2. Compile and install Crew through ESign

1. In GitHub, open **Actions → Build unsigned Crew IPA**.
2. Select **Run workflow**.
3. For `bundle_id`, use an identifier accepted by your provisioning profile. The default is `com.crew.personal`. Change it if your profile requires another ID.
4. Wait for the macOS build. A normal failure artifact contains `crew-build.log`; a successful artifact contains `Crew-unsigned.ipa`.
5. Download `Crew-unsigned-ipa.zip` onto your iPhone and extract it in Files.
6. Import `Crew-unsigned.ipa` into ESign.
7. Choose your valid certificate and provisioning profile, sign, and install.
8. On first launch, Crew opens in **demo mode**. This mode needs no service accounts.

The IPA is unsigned by design. Installing an unsigned IPA directly will not work; ESign must sign it first.

## 3. Create the free service credentials

### Groq

1. Create/sign into a Groq Cloud account.
2. Create an API key for the free plan.
3. Save it as GitHub secret `GROQ_API_KEY`.
4. The default model is configured as `openai/gpt-oss-20b` in `backend/wrangler.toml`. If your console no longer offers that model on the free tier, change `AI_MODEL` to a currently available free model before deploying.

Team-room requests can use two model calls (specialist + Ace), so direct chats consume less quota.

### Cloudflare

1. Create/sign into a Cloudflare account and open **Workers & Pages**.
2. Create a D1 database named `crew-db` and copy its database ID.
3. Copy your Account ID from the account/dashboard details.
4. Create a custom API token authorised for this account with the permissions needed to manage **Workers Scripts** and **D1**. Use the narrowest permissions Cloudflare offers for those resources.
5. Save these GitHub secrets:
   - `CLOUDFLARE_ACCOUNT_ID`
   - `CLOUDFLARE_API_TOKEN`
   - `D1_DATABASE_ID`

### Your private Crew token

Generate a long random token (at least 32 random characters). This is the app’s single-user password, not a provider key. Save it as `CREW_ACCESS_TOKEN`. You will also enter it in Crew later; iOS SecureStore keeps it on the phone.

### Bark

1. Install Bark on your iPhone and open it.
2. Copy the device key from your personal Bark URL. If the URL looks like `https://api.day.app/KEY/...`, only `KEY` is the device key.
3. Save it as `BARK_DEVICE_KEY`.
4. Optional: to keep notification content away from the public Bark service, deploy a Bark server and change `BARK_SERVER_URL` in `backend/wrangler.toml`.

## 4. Deploy the backend without a local terminal

In the GitHub repository, open **Settings → Secrets and variables → Actions** and add:

| Secret | Required | Purpose |
|---|---:|---|
| `CLOUDFLARE_API_TOKEN` | Yes | Lets the workflow deploy your Worker/D1 resources |
| `CLOUDFLARE_ACCOUNT_ID` | Yes | Selects your Cloudflare account |
| `D1_DATABASE_ID` | Yes | Binds your private routines/tokens database |
| `CREW_ACCESS_TOKEN` | Yes | Authenticates the single-user app |
| `GROQ_API_KEY` | Yes | Enables real AI replies |
| `BARK_DEVICE_KEY` | Recommended | Sends alerts to your iPhone |
| `GOOGLE_CLIENT_ID` | Later | Enables Google OAuth |
| `GOOGLE_CLIENT_SECRET` | Later | Enables Google OAuth |

Then:

1. Open **Actions → Deploy Crew backend → Run workflow**.
2. The workflow checks TypeScript, applies D1 migrations, stores provider secrets through Wrangler, and deploys `crew-api` with a 15-minute cron trigger.
3. Open **Cloudflare → Workers & Pages → crew-api** and copy its `https://crew-api.<your-subdomain>.workers.dev` URL.
4. Confirm the URL returns a small Crew API JSON response when opened without credentials. API data routes still require the private token.

## 5. Connect Gmail and Google Calendar

1. In Google Cloud Console, create/select a personal project.
2. Enable **Gmail API** and **Google Calendar API**.
3. Configure the OAuth consent screen. For a personal project, add your own Gmail address as a test user where requested.
4. Use only the scopes Crew requests:
   - `gmail.readonly` — read relevant message metadata/snippets for briefings
   - `gmail.compose` — create drafts after approval
   - `calendar.readonly` — read upcoming events for briefings
   - `calendar.events` — create a proposed event after approval
5. Create an OAuth client of type **Web application**.
6. Add this authorised redirect URI, replacing the host with your real Worker URL:

   ```text
   https://crew-api.<your-subdomain>.workers.dev/auth/google/callback
   ```

7. Save the client ID/secret as `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in GitHub Secrets.
8. Run **Deploy Crew backend** again to store those secrets.
9. In Crew, open **Settings → Set up live AI**. Enter the Worker URL and private Crew token, then tap **Save & test connection**.
10. Tap **Gmail + Calendar** and complete Google’s consent flow. You may see an unverified-app warning for a personal project; proceed only if this is your own expected OAuth client.
11. Tap **Bark alerts** to send a test notification.

Google’s consent/testing policies can require reauthorisation. If a routine reports expired access, reconnect Google in Settings rather than sharing the refresh token with anyone.

## 6. Verify the important flows

- **Direct live chat:** message Ace. The mode line should say `Live AI`.
- **Team handoff:** ask the team room to research and plan something. Scout/Milo should respond before Ace’s synthesis.
- **Voice:** open the central microphone, grant both permissions, and ask a short question. Keep the screen open for automatic follow-up listening.
- **Google briefing:** enable Morning brief and tap **Run now**. Check Bark and Activity.
- **Approval:** expand a Gmail proposal. In live mode the button should read **Create Gmail draft**. Confirm the draft exists in Gmail; Crew does not send it.
- **Free-limit behaviour:** if a provider returns 429, Crew shows a quota error instead of falling back silently to a fabricated live answer.

## Troubleshooting

**401 from the Worker**  
The app token and `CREW_ACCESS_TOKEN` secret differ. Save the correct one again in Settings.

**AI is connected but replies fail**  
Check the model name in `backend/wrangler.toml`, the Groq secret, and your current free-tier limits in Groq’s console. Redeploy after changing the model.

**Voice permission fails**  
Allow Microphone and Speech Recognition for Crew in iOS Settings. Make sure Siri & Dictation is enabled. On-device recognition also depends on device/language support; download the relevant speech model if iOS offers it.

**Google connects, then routines stop**  
Reconnect Google to refresh access. Check that your OAuth client remains authorised and your account is still an allowed test user.

**No Bark alert**  
Confirm the device key, run the test in Settings, and check Bark’s own notification permission. The public Bark service must also be reachable from Cloudflare.

**ESign rejects the app**  
Confirm that the bundle ID and app capabilities are covered by your own profile. Crew does not request push, iCloud, associated domains, or background-microphone entitlements.

## Cost and operating notes

- Free quotas are not service-level guarantees and may change without notice.
- Cloudflare’s included cron checks due routines every 15 minutes; exact second-by-second scheduling is not promised.
- Multi-agent answers use more AI quota than one-bot answers.
- The app does not include an always-on cloud browser, terminal, or virtual computer.
- Keep GitHub Actions logs public-safe. The supplied workflows do not print secret values, but provider error messages should still be reviewed before sharing logs.
